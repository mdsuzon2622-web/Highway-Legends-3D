package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import com.example.engine.HudTelemetry
import com.example.model.CameraMode
import com.example.model.EnvironmentId
import com.example.model.PlayerProgress
import com.example.model.SoundSettings
import com.example.model.SteeringMode
import com.example.monetization.OfflineTestAdProvider
import com.example.ui.screens.EnvironmentsScreen
import com.example.ui.screens.GarageScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.RacingHudOverlay
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.HighwayLegendsTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w800dp-h400dp-land")
class HighwayLegendsRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Test
    fun `main menu displays primary actions and triggers race navigation`() {
        var raceStarted = false
        var garageOpened = false

        composeRule.setContent {
            HighwayLegendsTheme {
                MainMenuScreen(
                    progress = PlayerProgress(),
                    adProvider = OfflineTestAdProvider(),
                    onStartRace = { raceStarted = true },
                    onOpenGarage = { garageOpened = true },
                    onOpenEnvironments = {},
                    onOpenSettings = {}
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("race_now_button").assertIsDisplayed().performClick()
        assertTrue(raceStarted)

        composeRule.onNodeWithTag("garage_button").assertIsDisplayed().performClick()
        assertTrue(garageOpened)
    }

    @Test
    fun `garage screen allows selecting cars and paint swatches`() {
        var selectedCar = ""
        var selectedPaint = -1

        composeRule.setContent {
            HighwayLegendsTheme {
                GarageScreen(
                    progress = PlayerProgress(),
                    onSelectCar = { carId, paintIdx ->
                        selectedCar = carId
                        selectedPaint = paintIdx
                    },
                    onStartRace = {},
                    onBack = {}
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("car_card_solaris_hyper").performClick()
        assertEquals("solaris_hyper", selectedCar)
        assertEquals(0, selectedPaint)
    }

    @Test
    fun `environments screen switches highways`() {
        var chosenEnv: EnvironmentId? = null

        composeRule.setContent {
            HighwayLegendsTheme {
                EnvironmentsScreen(
                    progress = PlayerProgress(),
                    onSelectEnvironment = { chosenEnv = it },
                    onStartRace = {},
                    onBack = {}
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("env_card_modern_city").performClick()
        assertEquals(EnvironmentId.MODERN_CITY, chosenEnv)
    }

    @Test
    fun `settings screen toggles steering mode`() {
        var current = SoundSettings()

        composeRule.setContent {
            HighwayLegendsTheme {
                SettingsScreen(
                    soundSettings = current,
                    onUpdateSettings = { fn -> current = fn(current) },
                    onBack = {}
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("steering_tilt_button").performClick()
        assertEquals(SteeringMode.TILT, current.steeringMode)
    }

    @Test
    fun `racing hud displays all driving controls and responds to camera and pause`() {
        var cameraSwitched = false
        var paused = false

        composeRule.setContent {
            HighwayLegendsTheme {
                RacingHudOverlay(
                    telemetry = HudTelemetry(
                        speedKmh = 185,
                        distanceMeters = 1420f,
                        gear = 4,
                        rpmNormalized = 0.72f,
                        cameraMode = CameraMode.CHASE_NEAR
                    ),
                    environmentId = EnvironmentId.COASTAL_ROAD,
                    steeringMode = SteeringMode.TOUCH,
                    leftHeld = false,
                    rightHeld = false,
                    gasHeld = false,
                    brakeHeld = false,
                    tiltSteerValue = 0f,
                    onLeftHeldChange = {},
                    onRightHeldChange = {},
                    onGasHeldChange = {},
                    onBrakeHeldChange = {},
                    onCycleCamera = { cameraSwitched = true },
                    onPause = { paused = true }
                )
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("speedometer_panel").assertIsDisplayed()
        composeRule.onNodeWithTag("distance_panel").assertIsDisplayed()
        composeRule.onNodeWithTag("steer_left_button").assertIsDisplayed()
        composeRule.onNodeWithTag("steer_right_button").assertIsDisplayed()
        composeRule.onNodeWithTag("brake_button").assertIsDisplayed()
        composeRule.onNodeWithTag("accelerate_button").assertIsDisplayed()

        composeRule.onNodeWithTag("camera_switch_button").performClick()
        assertTrue(cameraSwitched)

        composeRule.onNodeWithTag("pause_button").performClick()
        assertTrue(paused)
    }

    @Test
    fun `main activity launches without crashing and displays main menu`() {
        val controller = org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = controller.get()
        org.junit.Assert.assertNotNull(activity)
        org.junit.Assert.assertFalse(activity.isFinishing)
    }

    @Test
    fun `root game flow transitions from main menu to live racing hud and pause`() {
        val app = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.app.Application>()
        val vm = com.example.ui.GameViewModel(app)

        composeRule.setContent {
            HighwayLegendsTheme {
                HighwayLegendsRoot(viewModel = vm)
            }
        }

        composeRule.waitForIdle()
        composeRule.onNodeWithTag("race_now_button").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("speedometer_panel").assertIsDisplayed()
        composeRule.onNodeWithTag("accelerate_button").assertIsDisplayed()
        composeRule.onNodeWithTag("pause_button").assertIsDisplayed().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("resume_button").assertIsDisplayed()
    }
}
