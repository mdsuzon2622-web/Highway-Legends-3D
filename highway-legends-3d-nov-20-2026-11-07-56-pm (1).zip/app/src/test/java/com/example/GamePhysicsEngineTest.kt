package com.example

import com.example.engine.GamePhysicsEngine
import com.example.engine.HighwayTrackMath
import com.example.model.CameraMode
import com.example.model.CarCatalog
import com.example.model.EnvironmentCatalog
import com.example.model.EnvironmentId
import com.example.model.TrafficVehicle
import com.example.model.TrafficVehicleType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class GamePhysicsEngineTest {

    @Test
    fun `all 7 required environments are configured`() {
        val ids = EnvironmentCatalog.all.map { it.id }.toSet()
        assertEquals(7, ids.size)
        assertTrue(ids.contains(EnvironmentId.COUNTRYSIDE))
        assertTrue(ids.contains(EnvironmentId.MODERN_CITY))
        assertTrue(ids.contains(EnvironmentId.DENSE_FOREST))
        assertTrue(ids.contains(EnvironmentId.MOUNTAIN_HIGHWAY))
        assertTrue(ids.contains(EnvironmentId.COASTAL_ROAD))
        assertTrue(ids.contains(EnvironmentId.DESERT_HIGHWAY))
        assertTrue(ids.contains(EnvironmentId.NIGHTTIME_ROAD))
    }

    @Test
    fun `acceleration increases speed and distance while braking decreases speed`() {
        val engine = GamePhysicsEngine(Random(123))
        val car = CarCatalog.all.first()
        engine.startNewRace(car, 0)

        val initialSpeed = engine.speedKmh
        val initialZ = engine.playerZ

        engine.setControls(steer = 0f, throttle = 1f, brake = 0f)
        repeat(60) {
            engine.stepRace(0.016f)
        }

        assertTrue("Speed should increase under throttle", engine.speedKmh > initialSpeed + 10f)
        assertTrue("Distance should advance forward", engine.playerZ > initialZ + 15f)
        assertTrue("Speed should never exceed car topSpeedKmh", engine.speedKmh <= car.topSpeedKmh)

        val fastSpeed = engine.speedKmh
        engine.setControls(steer = 0f, throttle = 0f, brake = 1f)
        repeat(45) {
            engine.stepRace(0.016f)
        }
        assertTrue("Braking should slow down the car", engine.speedKmh < fastSpeed - 15f)
    }

    @Test
    fun `steering moves car smoothly left and right within highway bounds`() {
        val engine = GamePhysicsEngine(Random(456))
        engine.startNewRace(CarCatalog.all.first(), 0)
        val startX = engine.playerX

        engine.setControls(steer = -1f, throttle = 0.5f, brake = 0f)
        repeat(20) { engine.stepRace(0.016f) }
        assertTrue("Left steer should move playerX negative", engine.playerX < startX - 0.5f)

        val leftX = engine.playerX
        engine.setControls(steer = 1f, throttle = 0.5f, brake = 0f)
        repeat(40) { engine.stepRace(0.016f) }
        assertTrue("Right steer should move playerX positive", engine.playerX > leftX + 1.0f)

        // Ensure bounds clamping even under prolonged steering
        repeat(200) { engine.stepRace(0.016f) }
        assertTrue(engine.playerX <= HighwayTrackMath.MAX_PLAYER_X + 0.001f)
    }

    @Test
    fun `camera mode cycles through all 4 perspectives`() {
        val engine = GamePhysicsEngine(Random(1))
        assertEquals(CameraMode.CHASE_NEAR, engine.cameraMode)
        assertEquals(CameraMode.CHASE_FAR, engine.cycleCameraMode())
        assertEquals(CameraMode.HOOD, engine.cycleCameraMode())
        assertEquals(CameraMode.BUMPER, engine.cycleCameraMode())
        assertEquals(CameraMode.CHASE_NEAR, engine.cycleCameraMode())
    }

    @Test
    fun `collision detection triggers crash when overlapping traffic vehicle`() {
        val engine = GamePhysicsEngine(Random(789))
        engine.startNewRace(CarCatalog.all.first(), 0)
        assertFalse(engine.hasCrashed)

        // Inject a traffic vehicle directly ahead in the player's lane
        engine.injectTrafficForTest(
            TrafficVehicle(
                id = 9999,
                lane = 1,
                x = engine.playerX,
                z = engine.playerZ + 1.5f,
                speedKmh = 60f,
                type = TrafficVehicleType.SEDAN,
                colorRgb = floatArrayOf(1f, 0f, 0f)
            )
        )

        val crashed = engine.stepRace(0.016f)
        assertTrue("Collision should be detected", crashed)
        assertTrue("Engine should remain in crashed state", engine.hasCrashed)
    }
}
