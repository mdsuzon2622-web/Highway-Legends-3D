package com.example.render

import android.opengl.GLES20
import android.util.Log

private const val TAG = "HighwayShaders"

class WorldShaderProgram {
    val programId: Int
    val isValid: Boolean

    val uMvpMatrixLoc: Int
    val uModelMatrixLoc: Int
    val uCameraPosLoc: Int
    val uLightDirLoc: Int
    val uAmbientStrengthLoc: Int
    val uSunStrengthLoc: Int
    val uFogColorLoc: Int
    val uFogDensityLoc: Int
    val uColorTintLoc: Int
    val uEmissiveBoostLoc: Int
    val uSpecularStrengthLoc: Int
    val uAlphaLoc: Int

    val aPositionLoc: Int
    val aNormalLoc: Int
    val aColorLoc: Int

    init {
        val vertexSrc = """
            uniform highp mat4 uMvpMatrix;
            uniform highp mat4 uModelMatrix;
            uniform highp vec3 uCameraPos;

            attribute highp vec3 aPosition;
            attribute mediump vec3 aNormal;
            attribute mediump vec3 aColor;

            varying mediump vec3 vNormal;
            varying mediump vec3 vColor;
            varying mediump vec3 vToCamera;
            varying mediump float vViewDist;

            void main() {
                highp vec4 worldPos = uModelMatrix * vec4(aPosition, 1.0);
                highp vec3 toCam = uCameraPos - worldPos.xyz;
                vToCamera = toCam;
                vViewDist = length(toCam);
                vNormal = normalize((uModelMatrix * vec4(aNormal, 0.0)).xyz);
                vColor = aColor;
                gl_Position = uMvpMatrix * vec4(aPosition, 1.0);
            }
        """.trimIndent()

        val fragmentSrc = """
            precision mediump float;

            uniform mediump vec3 uLightDir;
            uniform mediump float uAmbientStrength;
            uniform mediump float uSunStrength;
            uniform mediump vec3 uFogColor;
            uniform mediump float uFogDensity;
            uniform mediump vec3 uColorTint;
            uniform mediump float uEmissiveBoost;
            uniform mediump float uSpecularStrength;
            uniform mediump float uAlpha;

            varying mediump vec3 vNormal;
            varying mediump vec3 vColor;
            varying mediump vec3 vToCamera;
            varying mediump float vViewDist;

            void main() {
                vec3 norm = normalize(vNormal);
                vec3 lightDir = normalize(uLightDir);
                float diff = max(dot(norm, lightDir), 0.0);

                // Hemisphere fill light for richer 3D form
                float hemi = clamp(norm.y * 0.5 + 0.5, 0.0, 1.0);
                vec3 ambient = vec3(uAmbientStrength * (0.72 + 0.28 * hemi));

                // Specular highlight for glossy paint & windshields
                vec3 viewDir = normalize(vToCamera);
                vec3 halfDir = normalize(lightDir + viewDir);
                float specBase = max(dot(norm, halfDir), 0.0001);
                float spec = pow(specBase, 28.0) * uSpecularStrength;

                vec3 baseColor = vColor * uColorTint;
                vec3 litColor = baseColor * (ambient + diff * uSunStrength) + vec3(spec) + baseColor * uEmissiveBoost;

                float fogArg = max(vViewDist * uFogDensity, 0.0001);
                float fogFactor = clamp(exp(-pow(fogArg, 1.6)), 0.0, 1.0);
                vec3 finalColor = mix(uFogColor, litColor, fogFactor);

                gl_FragColor = vec4(finalColor, uAlpha);
            }
        """.trimIndent()

        programId = linkProgram(vertexSrc, fragmentSrc)
        isValid = programId != 0
        if (isValid) {
            uMvpMatrixLoc = GLES20.glGetUniformLocation(programId, "uMvpMatrix")
            uModelMatrixLoc = GLES20.glGetUniformLocation(programId, "uModelMatrix")
            uCameraPosLoc = GLES20.glGetUniformLocation(programId, "uCameraPos")
            uLightDirLoc = GLES20.glGetUniformLocation(programId, "uLightDir")
            uAmbientStrengthLoc = GLES20.glGetUniformLocation(programId, "uAmbientStrength")
            uSunStrengthLoc = GLES20.glGetUniformLocation(programId, "uSunStrength")
            uFogColorLoc = GLES20.glGetUniformLocation(programId, "uFogColor")
            uFogDensityLoc = GLES20.glGetUniformLocation(programId, "uFogDensity")
            uColorTintLoc = GLES20.glGetUniformLocation(programId, "uColorTint")
            uEmissiveBoostLoc = GLES20.glGetUniformLocation(programId, "uEmissiveBoost")
            uSpecularStrengthLoc = GLES20.glGetUniformLocation(programId, "uSpecularStrength")
            uAlphaLoc = GLES20.glGetUniformLocation(programId, "uAlpha")

            aPositionLoc = GLES20.glGetAttribLocation(programId, "aPosition")
            aNormalLoc = GLES20.glGetAttribLocation(programId, "aNormal")
            aColorLoc = GLES20.glGetAttribLocation(programId, "aColor")
        } else {
            uMvpMatrixLoc = -1
            uModelMatrixLoc = -1
            uCameraPosLoc = -1
            uLightDirLoc = -1
            uAmbientStrengthLoc = -1
            uSunStrengthLoc = -1
            uFogColorLoc = -1
            uFogDensityLoc = -1
            uColorTintLoc = -1
            uEmissiveBoostLoc = -1
            uSpecularStrengthLoc = -1
            uAlphaLoc = -1
            aPositionLoc = -1
            aNormalLoc = -1
            aColorLoc = -1
        }
    }
}

class SkyShaderProgram {
    val programId: Int
    val isValid: Boolean
    val aPositionLoc: Int
    val aUvLoc: Int
    val uTopColorLoc: Int
    val uHorizonColorLoc: Int
    val uIsNightLoc: Int

    init {
        val vertexSrc = """
            attribute highp vec2 aPosition;
            attribute mediump float aUv;
            varying mediump float vHeight;
            void main() {
                vHeight = aUv;
                gl_Position = vec4(aPosition, 0.999, 1.0);
            }
        """.trimIndent()

        val fragmentSrc = """
            precision mediump float;
            uniform mediump vec3 uTopColor;
            uniform mediump vec3 uHorizonColor;
            uniform mediump float uIsNight;
            varying mediump float vHeight;
            void main() {
                float t = clamp(vHeight, 0.0001, 1.0);
                vec3 col = mix(uHorizonColor, uTopColor, pow(t, 0.72));
                if (uIsNight < 0.5) {
                    // Subtle warm horizon sun glow in daytime
                    float glow = exp(-abs(t - 0.12) * 14.0) * 0.14;
                    col += vec3(1.0, 0.92, 0.75) * glow;
                }
                gl_FragColor = vec4(col, 1.0);
            }
        """.trimIndent()

        programId = linkProgram(vertexSrc, fragmentSrc)
        isValid = programId != 0
        if (isValid) {
            aPositionLoc = GLES20.glGetAttribLocation(programId, "aPosition")
            aUvLoc = GLES20.glGetAttribLocation(programId, "aUv")
            uTopColorLoc = GLES20.glGetUniformLocation(programId, "uTopColor")
            uHorizonColorLoc = GLES20.glGetUniformLocation(programId, "uHorizonColor")
            uIsNightLoc = GLES20.glGetUniformLocation(programId, "uIsNight")
        } else {
            aPositionLoc = -1
            aUvLoc = -1
            uTopColorLoc = -1
            uHorizonColorLoc = -1
            uIsNightLoc = -1
        }
    }
}

private fun compileShader(type: Int, source: String): Int {
    val shader = GLES20.glCreateShader(type)
    if (shader == 0) {
        Log.e(TAG, "glCreateShader returned 0 for type=$type")
        return 0
    }
    GLES20.glShaderSource(shader, source)
    GLES20.glCompileShader(shader)
    val compiled = IntArray(1)
    GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0)
    if (compiled[0] == 0) {
        val log = GLES20.glGetShaderInfoLog(shader)
        Log.e(TAG, "Shader compile error: $log")
        GLES20.glDeleteShader(shader)
        return 0
    }
    return shader
}

private fun linkProgram(vertexSrc: String, fragmentSrc: String): Int {
    val vs = compileShader(GLES20.GL_VERTEX_SHADER, vertexSrc)
    val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSrc)
    if (vs == 0 || fs == 0) {
        if (vs != 0) GLES20.glDeleteShader(vs)
        if (fs != 0) GLES20.glDeleteShader(fs)
        return 0
    }
    val program = GLES20.glCreateProgram()
    if (program == 0) {
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)
        return 0
    }
    GLES20.glAttachShader(program, vs)
    GLES20.glAttachShader(program, fs)
    GLES20.glLinkProgram(program)
    val linked = IntArray(1)
    GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linked, 0)
    if (linked[0] == 0) {
        val log = GLES20.glGetProgramInfoLog(program)
        Log.e(TAG, "Program link error: $log")
        GLES20.glDeleteProgram(program)
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)
        return 0
    }
    GLES20.glDeleteShader(vs)
    GLES20.glDeleteShader(fs)
    return program
}
