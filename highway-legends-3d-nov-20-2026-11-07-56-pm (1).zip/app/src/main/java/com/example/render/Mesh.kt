package com.example.render

import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * Interleaved 3D mesh: x, y, z, nx, ny, nz, r, g, b (9 floats per vertex).
 */
class Mesh(vertices: FloatArray) {
    val vertexCount: Int = vertices.size / FLOATS_PER_VERTEX
    private var vboId: Int = 0
    private val buffer: FloatBuffer = ByteBuffer
        .allocateDirect(vertices.size * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(vertices)
            position(0)
        }

    init {
        val ids = IntArray(1)
        GLES20.glGenBuffers(1, ids, 0)
        vboId = ids[0]
        if (vboId != 0) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboId)
            GLES20.glBufferData(
                GLES20.GL_ARRAY_BUFFER,
                vertices.size * 4,
                buffer,
                GLES20.GL_STATIC_DRAW
            )
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        }
    }

    fun draw(shader: WorldShaderProgram) {
        if (vertexCount == 0 || !shader.isValid) return
        if (shader.aPositionLoc < 0 || shader.aNormalLoc < 0 || shader.aColorLoc < 0) return

        if (vboId != 0) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vboId)
            GLES20.glEnableVertexAttribArray(shader.aPositionLoc)
            GLES20.glVertexAttribPointer(shader.aPositionLoc, 3, GLES20.GL_FLOAT, false, STRIDE_BYTES, 0)

            GLES20.glEnableVertexAttribArray(shader.aNormalLoc)
            GLES20.glVertexAttribPointer(shader.aNormalLoc, 3, GLES20.GL_FLOAT, false, STRIDE_BYTES, 3 * 4)

            GLES20.glEnableVertexAttribArray(shader.aColorLoc)
            GLES20.glVertexAttribPointer(shader.aColorLoc, 3, GLES20.GL_FLOAT, false, STRIDE_BYTES, 6 * 4)

            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount)
            GLES20.glDisableVertexAttribArray(shader.aPositionLoc)
            GLES20.glDisableVertexAttribArray(shader.aNormalLoc)
            GLES20.glDisableVertexAttribArray(shader.aColorLoc)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        } else {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
            buffer.position(0)
            GLES20.glEnableVertexAttribArray(shader.aPositionLoc)
            GLES20.glVertexAttribPointer(shader.aPositionLoc, 3, GLES20.GL_FLOAT, false, STRIDE_BYTES, buffer)

            buffer.position(3)
            GLES20.glEnableVertexAttribArray(shader.aNormalLoc)
            GLES20.glVertexAttribPointer(shader.aNormalLoc, 3, GLES20.GL_FLOAT, false, STRIDE_BYTES, buffer)

            buffer.position(6)
            GLES20.glEnableVertexAttribArray(shader.aColorLoc)
            GLES20.glVertexAttribPointer(shader.aColorLoc, 3, GLES20.GL_FLOAT, false, STRIDE_BYTES, buffer)

            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount)
            GLES20.glDisableVertexAttribArray(shader.aPositionLoc)
            GLES20.glDisableVertexAttribArray(shader.aNormalLoc)
            GLES20.glDisableVertexAttribArray(shader.aColorLoc)
        }
    }

    companion object {
        const val FLOATS_PER_VERTEX = 9
        const val STRIDE_BYTES = FLOATS_PER_VERTEX * 4
    }
}

class DynamicVertexStream(maxFloats: Int) {
    private val buffer: FloatBuffer = ByteBuffer
        .allocateDirect(maxFloats * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
    private var data = FloatArray(maxFloats)
    private var floatCount = 0

    fun reset() {
        floatCount = 0
    }

    fun addTriangle(
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        nx: Float, ny: Float, nz: Float,
        r: Float, g: Float, b: Float
    ) {
        ensureCapacity(27)
        val i = floatCount
        data[i] = x1; data[i + 1] = y1; data[i + 2] = z1
        data[i + 3] = nx; data[i + 4] = ny; data[i + 5] = nz
        data[i + 6] = r; data[i + 7] = g; data[i + 8] = b

        data[i + 9] = x2; data[i + 10] = y2; data[i + 11] = z2
        data[i + 12] = nx; data[i + 13] = ny; data[i + 14] = nz
        data[i + 15] = r; data[i + 16] = g; data[i + 17] = b

        data[i + 18] = x3; data[i + 19] = y3; data[i + 20] = z3
        data[i + 21] = nx; data[i + 22] = ny; data[i + 23] = nz
        data[i + 24] = r; data[i + 25] = g; data[i + 26] = b
        floatCount += 27
    }

    fun addQuad(
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        x4: Float, y4: Float, z4: Float,
        nx: Float, ny: Float, nz: Float,
        r: Float, g: Float, b: Float
    ) {
        addTriangle(x1, y1, z1, x2, y2, z2, x3, y3, z3, nx, ny, nz, r, g, b)
        addTriangle(x1, y1, z1, x3, y3, z3, x4, y4, z4, nx, ny, nz, r, g, b)
    }

    private fun ensureCapacity(extra: Int) {
        if (floatCount + extra > data.size) {
            data = data.copyOf(data.size * 2)
        }
    }

    fun draw(shader: WorldShaderProgram) {
        if (!shader.isValid) return
        if (shader.aPositionLoc < 0 || shader.aNormalLoc < 0 || shader.aColorLoc < 0) return

        val vCount = floatCount / Mesh.FLOATS_PER_VERTEX
        if (vCount == 0) return
        buffer.clear()
        if (buffer.capacity() < floatCount) return
        buffer.put(data, 0, floatCount)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        buffer.position(0)
        GLES20.glEnableVertexAttribArray(shader.aPositionLoc)
        GLES20.glVertexAttribPointer(shader.aPositionLoc, 3, GLES20.GL_FLOAT, false, Mesh.STRIDE_BYTES, buffer)

        buffer.position(3)
        GLES20.glEnableVertexAttribArray(shader.aNormalLoc)
        GLES20.glVertexAttribPointer(shader.aNormalLoc, 3, GLES20.GL_FLOAT, false, Mesh.STRIDE_BYTES, buffer)

        buffer.position(6)
        GLES20.glEnableVertexAttribArray(shader.aColorLoc)
        GLES20.glVertexAttribPointer(shader.aColorLoc, 3, GLES20.GL_FLOAT, false, Mesh.STRIDE_BYTES, buffer)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vCount)
        GLES20.glDisableVertexAttribArray(shader.aPositionLoc)
        GLES20.glDisableVertexAttribArray(shader.aNormalLoc)
        GLES20.glDisableVertexAttribArray(shader.aColorLoc)
    }
}
