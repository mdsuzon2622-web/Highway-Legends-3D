package com.example.render

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.Log
import com.example.engine.GamePhysicsEngine
import com.example.engine.HighwayTrackMath
import com.example.engine.RenderSnapshot
import com.example.model.CameraMode
import com.example.model.CarCatalog
import com.example.model.EnvironmentCatalog
import com.example.model.EnvironmentId
import com.example.model.EnvironmentTheme
import com.example.model.TrafficVehicleType
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

class HighwayGLRenderer(
    private val physicsEngine: GamePhysicsEngine
) : GLSurfaceView.Renderer {

    @Volatile
    var isShowcaseMode: Boolean = true

    @Volatile
    var currentEnvironmentId: EnvironmentId = EnvironmentId.COUNTRYSIDE

    private lateinit var worldShader: WorldShaderProgram
    private lateinit var skyShader: SkyShaderProgram
    private lateinit var skyBuffer: FloatBuffer

    private lateinit var wheelMesh: Mesh
    private lateinit var headlightConeMesh: Mesh
    private val carBodyMeshes = HashMap<String, Mesh>()
    private val carTailMeshes = HashMap<String, Mesh>()
    private val trafficMeshes = HashMap<TrafficVehicleType, Mesh>()

    // Scenery meshes
    private lateinit var pineTreeMesh: Mesh
    private lateinit var barnMesh: Mesh
    private lateinit var skyscraperTallMesh: Mesh
    private lateinit var skyscraperMidMesh: Mesh
    private lateinit var mountainPeakMesh: Mesh
    private lateinit var palmTreeMesh: Mesh
    private lateinit var desertMesaMesh: Mesh
    private lateinit var cactusMesh: Mesh
    private lateinit var streetLampLeftMesh: Mesh
    private lateinit var streetLampRightMesh: Mesh
    private lateinit var highwayGantryMesh: Mesh

    private val roadStream = DynamicVertexStream(maxFloats = 160000)

    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    @Volatile
    private var surfaceReady: Boolean = false
    private var aspectRatio: Float = 16f / 9f
    private var lastFrameNanos: Long = System.nanoTime()
    private var cameraLatSmooth: Float = 0f

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        surfaceReady = false
        try {
            GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            GLES20.glDisable(GLES20.GL_CULL_FACE)

            worldShader = WorldShaderProgram()
            skyShader = SkyShaderProgram()

            // Fullscreen sky quad: (x, y, uvY)
            val skyData = floatArrayOf(
                -1f, -1f, 0f,
                1f, -1f, 0f,
                1f, 1f, 1f,
                -1f, -1f, 0f,
                1f, 1f, 1f,
                -1f, 1f, 1f
            )
            skyBuffer = ByteBuffer.allocateDirect(skyData.size * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
                .apply {
                    put(skyData)
                    position(0)
                }

            wheelMesh = CarMeshFactory.buildWheelMesh()
            headlightConeMesh = buildHeadlightConeMesh()

            carBodyMeshes.clear()
            carTailMeshes.clear()
            for (car in CarCatalog.all) {
                carTailMeshes[car.id] = CarMeshFactory.buildTailLightBarMesh(car)
                for (pIdx in car.paintOptions.indices) {
                    carBodyMeshes["${car.id}_$pIdx"] = CarMeshFactory.buildSportsCarBodyMesh(car, pIdx)
                }
            }

            trafficMeshes.clear()
            for (t in TrafficVehicleType.entries) {
                trafficMeshes[t] = CarMeshFactory.buildTrafficMesh(t)
            }

            buildSceneryMeshes()
            lastFrameNanos = System.nanoTime()
            surfaceReady = worldShader.isValid && skyShader.isValid
        } catch (t: Throwable) {
            Log.e("HighwayGLRenderer", "Failed to initialize OpenGL surface", t)
            surfaceReady = false
        }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        aspectRatio = if (width > 0 && height > 0) width.toFloat() / height.toFloat() else 16f / 9f
    }

    override fun onDrawFrame(gl: GL10?) {
        try {
            val now = System.nanoTime()
            val dt = ((now - lastFrameNanos) / 1_000_000_000.0f).coerceIn(0.001f, 0.05f)
            lastFrameNanos = now

            if (isShowcaseMode) {
                physicsEngine.stepShowcase(dt)
            }

            val snap = physicsEngine.getRenderSnapshot()
            val env = EnvironmentCatalog.byId(currentEnvironmentId)

            GLES20.glClearColor(env.fogRgb[0], env.fogRgb[1], env.fogRgb[2], 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

            if (!surfaceReady || !worldShader.isValid || !skyShader.isValid) return

        // 1. Draw atmospheric sky gradient without depth write
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(false)
        drawSky(env)
        GLES20.glDepthMask(true)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)

        // 2. Setup 3D Perspective & Camera
        val speedNorm = (snap.speedKmh / 330f).coerceIn(0f, 1f)
        val fov = if (isShowcaseMode) 48f else (54f + speedNorm * 13f)
        Matrix.perspectiveM(projMatrix, 0, fov, aspectRatio, 0.35f, 290f)

        val playerZ = snap.playerZ
        val roadCenterX = HighwayTrackMath.roadCurveX(playerZ)
        val roadY = HighwayTrackMath.roadHillY(playerZ)
        val roadAngleRad = atan2(HighwayTrackMath.roadCurveSlopeX(playerZ), 1f)

        val playerWorldX = roadCenterX + snap.playerX
        val playerWorldY = roadY

        var camX: Float
        var camY: Float
        var camZ: Float
        var lookX: Float
        var lookY: Float
        var lookZ: Float

        if (isShowcaseMode) {
            val orbitR = 6.2f
            val angle = snap.showcaseAngleRad
            camX = roadCenterX + sin(angle) * orbitR
            camY = roadY + 2.15f
            camZ = playerZ - cos(angle) * orbitR
            lookX = roadCenterX
            lookY = roadY + 0.72f
            lookZ = playerZ + 0.2f
        } else {
            cameraLatSmooth += (snap.playerX - cameraLatSmooth) * (dt * 8f).coerceIn(0f, 1f)
            val shakeX = if (snap.cameraShake > 0f) sin(now * 0.0001f) * 0.32f * snap.cameraShake else 0f
            val shakeY = if (snap.cameraShake > 0f) cos(now * 0.00013f) * 0.24f * snap.cameraShake else 0f

            val forwardLookZ = playerZ + 22f
            val forwardRoadX = HighwayTrackMath.roadCurveX(forwardLookZ)
            val forwardRoadY = HighwayTrackMath.roadHillY(forwardLookZ)

            when (snap.cameraMode) {
                CameraMode.CHASE_NEAR -> {
                    val backDist = 6.3f + speedNorm * 1.1f
                    val camZPos = playerZ - backDist
                    camX = HighwayTrackMath.roadCurveX(camZPos) + cameraLatSmooth * 0.88f + shakeX
                    camY = HighwayTrackMath.roadHillY(camZPos) + 2.35f + shakeY
                    camZ = camZPos
                    lookX = forwardRoadX + snap.playerX * 0.75f
                    lookY = forwardRoadY + 1.05f
                    lookZ = forwardLookZ
                }

                CameraMode.CHASE_FAR -> {
                    val backDist = 9.8f + speedNorm * 1.4f
                    val camZPos = playerZ - backDist
                    camX = HighwayTrackMath.roadCurveX(camZPos) + cameraLatSmooth * 0.78f + shakeX
                    camY = HighwayTrackMath.roadHillY(camZPos) + 3.85f + shakeY
                    camZ = camZPos
                    lookX = forwardRoadX + snap.playerX * 0.65f
                    lookY = forwardRoadY + 0.90f
                    lookZ = forwardLookZ + 4f
                }

                CameraMode.HOOD -> {
                    camX = playerWorldX + shakeX * 0.4f
                    camY = playerWorldY + 1.18f + shakeY * 0.4f
                    camZ = playerZ + 0.75f
                    lookX = forwardRoadX + snap.playerX * 0.92f
                    lookY = forwardRoadY + 0.95f
                    lookZ = forwardLookZ + 8f
                }

                CameraMode.BUMPER -> {
                    camX = playerWorldX + shakeX * 0.3f
                    camY = playerWorldY + 0.56f + shakeY * 0.3f
                    camZ = playerZ + 2.18f
                    lookX = forwardRoadX + snap.playerX * 0.95f
                    lookY = forwardRoadY + 0.65f
                    lookZ = forwardLookZ + 12f
                }
            }
        }

        Matrix.setLookAtM(viewMatrix, 0, camX, camY, camZ, lookX, lookY, lookZ, 0f, 1f, 0f)
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        // 3. Activate World Shader with Environment Lighting & Fog
        GLES20.glUseProgram(worldShader.programId)
        GLES20.glUniform3f(worldShader.uCameraPosLoc, camX, camY, camZ)
        if (env.isNight) {
            GLES20.glUniform3f(worldShader.uLightDirLoc, -0.35f, 0.75f, 0.45f)
        } else {
            GLES20.glUniform3f(worldShader.uLightDirLoc, 0.45f, 0.85f, 0.32f)
        }
        GLES20.glUniform1f(worldShader.uAmbientStrengthLoc, env.ambientStrength)
        GLES20.glUniform1f(worldShader.uSunStrengthLoc, env.sunStrength)
        GLES20.glUniform3fv(worldShader.uFogColorLoc, 1, env.fogRgb, 0)
        GLES20.glUniform1f(worldShader.uFogDensityLoc, if (env.isNight) 0.0046f else 0.0036f)
        GLES20.glUniform3f(worldShader.uColorTintLoc, 1f, 1f, 1f)
        GLES20.glUniform1f(worldShader.uEmissiveBoostLoc, 0f)
        GLES20.glUniform1f(worldShader.uSpecularStrengthLoc, 0.05f)
        GLES20.glUniform1f(worldShader.uAlphaLoc, 1.0f)

        // 4. Draw Dynamic 3D Highway Ribbon (Asphalt, Lanes, Shoulders, Guardrails, Terrain/Ocean)
        drawHighwayRibbon(playerZ, env)

        // 5. Draw Environment 3D Scenery Props
        drawEnvironmentScenery(playerZ, env)

        // 6. Draw 3D Traffic Vehicles
        if (!isShowcaseMode) {
            drawTraffic(snap, env)
        }

        // 7. Draw Player 3D Sports Car (unless Bumper cam hides car body)
        if (isShowcaseMode || snap.cameraMode != CameraMode.BUMPER) {
            val carX = if (isShowcaseMode) roadCenterX else playerWorldX
            val yawDeg = if (isShowcaseMode) {
                Math.toDegrees(roadAngleRad.toDouble()).toFloat()
            } else {
                Math.toDegrees(roadAngleRad.toDouble()).toFloat() - snap.steerVisualAngleDeg
            }
            val rollDeg = if (isShowcaseMode) 0f else snap.bodyRollDeg
            drawPlayerSportsCar(snap, env, carX, roadY, playerZ, yawDeg, rollDeg)
        }
        } catch (t: Throwable) {
            Log.e("HighwayGLRenderer", "Render frame error", t)
        }
    }

    private fun drawSky(env: EnvironmentTheme) {
        if (skyShader.aPositionLoc < 0 || skyShader.aUvLoc < 0) return
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glUseProgram(skyShader.programId)
        GLES20.glUniform3fv(skyShader.uTopColorLoc, 1, env.skyTopRgb, 0)
        GLES20.glUniform3fv(skyShader.uHorizonColorLoc, 1, env.skyHorizonRgb, 0)
        GLES20.glUniform1f(skyShader.uIsNightLoc, if (env.isNight) 1f else 0f)

        skyBuffer.position(0)
        GLES20.glEnableVertexAttribArray(skyShader.aPositionLoc)
        GLES20.glVertexAttribPointer(skyShader.aPositionLoc, 2, GLES20.GL_FLOAT, false, 12, skyBuffer)

        skyBuffer.position(2)
        GLES20.glEnableVertexAttribArray(skyShader.aUvLoc)
        GLES20.glVertexAttribPointer(skyShader.aUvLoc, 1, GLES20.GL_FLOAT, false, 12, skyBuffer)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6)
        GLES20.glDisableVertexAttribArray(skyShader.aPositionLoc)
        GLES20.glDisableVertexAttribArray(skyShader.aUvLoc)
    }

    private fun drawHighwayRibbon(playerZ: Float, env: EnvironmentTheme) {
        roadStream.reset()
        val step = 5f
        val startZ = floor((playerZ - 20f) / step) * step
        val endZ = startZ + 260f

        val halfRoad = HighwayTrackMath.ROAD_WIDTH * 0.5f // 7.2
        val halfShoulder = halfRoad + HighwayTrackMath.SHOULDER_WIDTH // 8.8
        val terrainOuter = 85f

        val rRoad = env.roadRgb[0]; val gRoad = env.roadRgb[1]; val bRoad = env.roadRgb[2]
        val rSh = env.shoulderRgb[0]; val gSh = env.shoulderRgb[1]; val bSh = env.shoulderRgb[2]
        val rLine = env.laneLineRgb[0]; val gLine = env.laneLineRgb[1]; val bLine = env.laneLineRgb[2]
        val rLeft = env.groundLeftRgb[0]; val gLeft = env.groundLeftRgb[1]; val bLeft = env.groundLeftRgb[2]
        val rRight = env.groundRightRgb[0]; val gRight = env.groundRightRgb[1]; val bRight = env.groundRightRgb[2]

        var z0 = startZ
        while (z0 < endZ) {
            val z1 = z0 + step
            val cx0 = HighwayTrackMath.roadCurveX(z0)
            val cy0 = HighwayTrackMath.roadHillY(z0)
            val cx1 = HighwayTrackMath.roadCurveX(z1)
            val cy1 = HighwayTrackMath.roadHillY(z1)

            // Subtle terrain shade alternation for speed perception
            val band = ((floor(z0 / step).toInt() and 1) == 0)
            val shade = if (band) 1.0f else 0.94f

            // Asphalt road surface
            roadStream.addQuad(
                cx0 - halfRoad, cy0, z0,
                cx0 + halfRoad, cy0, z0,
                cx1 + halfRoad, cy1, z1,
                cx1 - halfRoad, cy1, z1,
                0f, 1f, 0f,
                rRoad * shade, gRoad * shade, bRoad * shade
            )

            // Left & right shoulders
            roadStream.addQuad(
                cx0 - halfShoulder, cy0 - 0.01f, z0,
                cx0 - halfRoad, cy0, z0,
                cx1 - halfRoad, cy1, z1,
                cx1 - halfShoulder, cy1 - 0.01f, z1,
                0f, 1f, 0f,
                rSh * shade, gSh * shade, bSh * shade
            )
            roadStream.addQuad(
                cx0 + halfRoad, cy0, z0,
                cx0 + halfShoulder, cy0 - 0.01f, z0,
                cx1 + halfShoulder, cy1 - 0.01f, z1,
                cx1 + halfRoad, cy1, z1,
                0f, 1f, 0f,
                rSh * shade, gSh * shade, bSh * shade
            )

            // Continuous edge stripes
            val edgeW = 0.14f
            roadStream.addQuad(
                cx0 - halfRoad + 0.12f, cy0 + 0.02f, z0,
                cx0 - halfRoad + 0.12f + edgeW, cy0 + 0.02f, z0,
                cx1 - halfRoad + 0.12f + edgeW, cy1 + 0.02f, z1,
                cx1 - halfRoad + 0.12f, cy1 + 0.02f, z1,
                0f, 1f, 0f,
                0.96f, 0.78f, 0.16f
            )
            roadStream.addQuad(
                cx0 + halfRoad - 0.12f - edgeW, cy0 + 0.02f, z0,
                cx0 + halfRoad - 0.12f, cy0 + 0.02f, z0,
                cx1 + halfRoad - 0.12f, cy1 + 0.02f, z1,
                cx1 + halfRoad - 0.12f - edgeW, cy1 + 0.02f, z1,
                0f, 1f, 0f,
                0.96f, 0.78f, 0.16f
            )

            // Dashed lane dividers (3 inner lane dividers for 4 lanes)
            val dashCycle = (floor(z0 / 10f).toInt() and 1) == 0
            if (dashCycle) {
                for (laneSep in -1..1) {
                    val lx = laneSep * HighwayTrackMath.LANE_WIDTH
                    val lw = 0.11f
                    roadStream.addQuad(
                        cx0 + lx - lw, cy0 + 0.025f, z0,
                        cx0 + lx + lw, cy0 + 0.025f, z0,
                        cx1 + lx + lw, cy1 + 0.025f, z1,
                        cx1 + lx - lw, cy1 + 0.025f, z1,
                        0f, 1f, 0f,
                        rLine, gLine, bLine
                    )
                }
            }

            // Steel Guardrails (both sides)
            val railX = halfShoulder - 0.25f
            val railColor = if (env.isNight) 0.36f else 0.74f
            // Left guardrail face
            roadStream.addQuad(
                cx0 - railX, cy0 + 0.42f, z0,
                cx0 - railX, cy0 + 0.76f, z0,
                cx1 - railX, cy1 + 0.76f, z1,
                cx1 - railX, cy1 + 0.42f, z1,
                1f, 0f, 0f,
                railColor, railColor, railColor * 1.04f
            )
            // Right guardrail face
            roadStream.addQuad(
                cx0 + railX, cy0 + 0.42f, z0,
                cx0 + railX, cy0 + 0.76f, z0,
                cx1 + railX, cy1 + 0.76f, z1,
                cx1 + railX, cy1 + 0.42f, z1,
                -1f, 0f, 0f,
                railColor, railColor, railColor * 1.04f
            )

            // Left terrain ground
            roadStream.addQuad(
                cx0 - terrainOuter, cy0 - 0.05f, z0,
                cx0 - halfShoulder, cy0 - 0.02f, z0,
                cx1 - halfShoulder, cy1 - 0.02f, z1,
                cx1 - terrainOuter, cy1 - 0.05f, z1,
                0f, 1f, 0f,
                rLeft * shade, gLeft * shade, bLeft * shade
            )

            // Right terrain (or ocean for Coastal Road!)
            val rightY = if (env.hasOceanRight) -0.45f else -0.05f
            roadStream.addQuad(
                cx0 + halfShoulder, cy0 - 0.02f, z0,
                cx0 + terrainOuter, cy0 + rightY, z0,
                cx1 + terrainOuter, cy1 + rightY, z1,
                cx1 + halfShoulder, cy1 - 0.02f, z1,
                0f, 1f, 0f,
                rRight * shade, gRight * shade, bRight * shade
            )

            z0 = z1
        }

        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(worldShader.uModelMatrixLoc, 1, false, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(worldShader.uMvpMatrixLoc, 1, false, mvpMatrix, 0)
        GLES20.glUniform3f(worldShader.uColorTintLoc, 1f, 1f, 1f)
        GLES20.glUniform1f(worldShader.uEmissiveBoostLoc, 0f)
        GLES20.glUniform1f(worldShader.uSpecularStrengthLoc, 0.08f)

        roadStream.draw(worldShader)
    }

    private fun drawEnvironmentScenery(playerZ: Float, env: EnvironmentTheme) {
        val propSpacing = when (env.id) {
            EnvironmentId.DENSE_FOREST -> 14f
            EnvironmentId.MODERN_CITY -> 22f
            else -> 18f
        }
        val firstIdx = floor((playerZ - 15f) / propSpacing).toInt()
        val lastIdx = floor((playerZ + 235f) / propSpacing).toInt()

        for (idx in firstIdx..lastIdx) {
            val z = idx * propSpacing
            val cx = HighwayTrackMath.roadCurveX(z)
            val cy = HighwayTrackMath.roadHillY(z)
            val roadYaw = Math.toDegrees(atan2(HighwayTrackMath.roadCurveSlopeX(z), 1f).toDouble()).toFloat()

            // Periodic highway gantry arch every 8 props
            if (idx % 9 == 0) {
                drawMeshAt(
                    highwayGantryMesh,
                    cx, cy, z,
                    yawDeg = roadYaw,
                    emissive = if (env.isNight) 0.18f else 0f
                )
            }

            when (env.id) {
                EnvironmentId.COUNTRYSIDE -> {
                    val leftDist = 13.5f + ((idx * 7) % 9)
                    val rightDist = 14.0f + ((idx * 5) % 10)
                    if (idx % 5 == 0) {
                        drawMeshAt(barnMesh, cx - leftDist - 5f, cy, z, yawDeg = roadYaw)
                    } else {
                        drawMeshAt(pineTreeMesh, cx - leftDist, cy, z, scale = 1.0f + (idx % 3) * 0.18f)
                    }
                    drawMeshAt(pineTreeMesh, cx + rightDist, cy, z + 4f, scale = 1.1f + (idx % 2) * 0.2f)
                }

                EnvironmentId.MODERN_CITY -> {
                    val leftX = cx - 18f - (idx % 3) * 3f
                    val rightX = cx + 18f + ((idx + 1) % 3) * 3f
                    val leftMesh = if (idx % 2 == 0) skyscraperTallMesh else skyscraperMidMesh
                    val rightMesh = if (idx % 2 == 1) skyscraperTallMesh else skyscraperMidMesh
                    drawMeshAt(leftMesh, leftX, cy, z, yawDeg = roadYaw, specular = 0.55f)
                    drawMeshAt(rightMesh, rightX, cy, z, yawDeg = roadYaw, specular = 0.55f)
                    drawMeshAt(streetLampLeftMesh, cx - 9.4f, cy, z, yawDeg = roadYaw)
                    drawMeshAt(streetLampRightMesh, cx + 9.4f, cy, z, yawDeg = roadYaw)
                }

                EnvironmentId.DENSE_FOREST -> {
                    drawMeshAt(pineTreeMesh, cx - 11.2f, cy, z, scale = 1.45f)
                    drawMeshAt(pineTreeMesh, cx - 17.5f, cy, z + 5f, scale = 1.85f)
                    drawMeshAt(pineTreeMesh, cx + 11.2f, cy, z + 2f, scale = 1.50f)
                    drawMeshAt(pineTreeMesh, cx + 17.8f, cy, z + 7f, scale = 1.90f)
                }

                EnvironmentId.MOUNTAIN_HIGHWAY -> {
                    val leftScale = 1.2f + (idx % 3) * 0.35f
                    val rightScale = 1.1f + ((idx + 1) % 3) * 0.30f
                    drawMeshAt(mountainPeakMesh, cx - 22f, cy - 0.5f, z, yawDeg = roadYaw, scale = leftScale)
                    drawMeshAt(mountainPeakMesh, cx + 23f, cy - 0.5f, z + 6f, yawDeg = roadYaw, scale = rightScale)
                    if (idx % 2 == 0) {
                        drawMeshAt(pineTreeMesh, cx - 11.5f, cy, z + 3f, scale = 1.05f)
                    }
                }

                EnvironmentId.COASTAL_ROAD -> {
                    // Palm trees along left beach & shoreline
                    drawMeshAt(palmTreeMesh, cx - 11.4f, cy, z, yawDeg = ((idx * 37) % 360).toFloat(), scale = 1.15f)
                    if (idx % 2 == 0) {
                        drawMeshAt(mountainPeakMesh, cx - 26f, cy, z, yawDeg = roadYaw, scale = 0.85f)
                    }
                }

                EnvironmentId.DESERT_HIGHWAY -> {
                    if (idx % 3 == 0) {
                        drawMeshAt(desertMesaMesh, cx - 23f, cy, z, yawDeg = roadYaw, scale = 1.2f)
                        drawMeshAt(desertMesaMesh, cx + 24f, cy, z + 8f, yawDeg = roadYaw, scale = 1.0f)
                    } else {
                        drawMeshAt(cactusMesh, cx - 12.2f - (idx % 4) * 2f, cy, z, scale = 1.1f)
                        drawMeshAt(cactusMesh, cx + 12.5f + (idx % 3) * 2f, cy, z + 5f, scale = 1.2f)
                    }
                }

                EnvironmentId.NIGHTTIME_ROAD -> {
                    drawMeshAt(streetLampLeftMesh, cx - 9.4f, cy, z, yawDeg = roadYaw, emissive = 0.52f)
                    drawMeshAt(streetLampRightMesh, cx + 9.4f, cy, z, yawDeg = roadYaw, emissive = 0.52f)
                    if (idx % 2 == 0) {
                        drawMeshAt(skyscraperMidMesh, cx - 22f, cy, z, yawDeg = roadYaw, emissive = 0.25f)
                        drawMeshAt(skyscraperTallMesh, cx + 23f, cy, z, yawDeg = roadYaw, emissive = 0.25f)
                    }
                }
            }
        }
    }

    private fun drawTraffic(snap: RenderSnapshot, env: EnvironmentTheme) {
        for (v in snap.traffic) {
            val roadX = HighwayTrackMath.roadCurveX(v.z)
            val roadY = HighwayTrackMath.roadHillY(v.z)
            val roadYaw = Math.toDegrees(atan2(HighwayTrackMath.roadCurveSlopeX(v.z), 1f).toDouble()).toFloat()
            val mesh = trafficMeshes[v.type] ?: continue

            drawMeshAt(
                mesh = mesh,
                x = roadX + v.x,
                y = roadY,
                z = v.z,
                yawDeg = roadYaw,
                tint = v.colorRgb,
                specular = 0.45f,
                emissive = if (env.isNight) 0.12f else 0f
            )
        }
    }

    private fun drawPlayerSportsCar(
        snap: RenderSnapshot,
        env: EnvironmentTheme,
        x: Float,
        y: Float,
        z: Float,
        yawDeg: Float,
        rollDeg: Float
    ) {
        val bodyKey = "${snap.carSpec.id}_${snap.paintIndex}"
        val bodyMesh = carBodyMeshes[bodyKey] ?: return
        val tailMesh = carTailMeshes[snap.carSpec.id]

        // Car body transform
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, x, y, z)
        Matrix.rotateM(modelMatrix, 0, yawDeg, 0f, 1f, 0f)
        Matrix.rotateM(modelMatrix, 0, rollDeg, 0f, 0f, 1f)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)

        GLES20.glUniformMatrix4fv(worldShader.uModelMatrixLoc, 1, false, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(worldShader.uMvpMatrixLoc, 1, false, mvpMatrix, 0)
        GLES20.glUniform3f(worldShader.uColorTintLoc, 1f, 1f, 1f)
        GLES20.glUniform1f(worldShader.uEmissiveBoostLoc, 0f)
        GLES20.glUniform1f(worldShader.uSpecularStrengthLoc, 0.72f)
        bodyMesh.draw(worldShader)

        // Glowing taillights (boosted when braking or at night)
        if (tailMesh != null) {
            val tailGlow = when {
                snap.isBraking -> 1.15f
                env.isNight -> 0.65f
                else -> 0.25f
            }
            GLES20.glUniform1f(worldShader.uEmissiveBoostLoc, tailGlow)
            tailMesh.draw(worldShader)
            GLES20.glUniform1f(worldShader.uEmissiveBoostLoc, 0f)
        }

        // 4 spinning 3D wheels
        val wheelX = snap.carSpec.width * 0.45f
        val wheelZ = snap.carSpec.length * 0.30f
        val wheelDeg = Math.toDegrees(snap.wheelSpinRad.toDouble()).toFloat()
        val frontSteerDeg = -snap.steerVisualAngleDeg * 1.4f

        drawWheel(x, y, z, yawDeg, rollDeg, -wheelX, 0.34f, wheelZ, wheelDeg, frontSteerDeg)
        drawWheel(x, y, z, yawDeg, rollDeg, wheelX, 0.34f, wheelZ, wheelDeg, frontSteerDeg)
        drawWheel(x, y, z, yawDeg, rollDeg, -wheelX, 0.34f, -wheelZ, wheelDeg, 0f)
        drawWheel(x, y, z, yawDeg, rollDeg, wheelX, 0.34f, -wheelZ, wheelDeg, 0f)

        // Headlight asphalt beams at night
        if (env.isNight) {
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            GLES20.glDepthMask(false)

            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, x, y + 0.04f, z)
            Matrix.rotateM(modelMatrix, 0, yawDeg, 0f, 1f, 0f)
            Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)

            GLES20.glUniformMatrix4fv(worldShader.uModelMatrixLoc, 1, false, modelMatrix, 0)
            GLES20.glUniformMatrix4fv(worldShader.uMvpMatrixLoc, 1, false, mvpMatrix, 0)
            GLES20.glUniform1f(worldShader.uEmissiveBoostLoc, 0.85f)
            GLES20.glUniform1f(worldShader.uAlphaLoc, 0.28f)
            headlightConeMesh.draw(worldShader)

            GLES20.glUniform1f(worldShader.uAlphaLoc, 1.0f)
            GLES20.glUniform1f(worldShader.uEmissiveBoostLoc, 0f)
            GLES20.glDepthMask(true)
            GLES20.glDisable(GLES20.GL_BLEND)
        }
    }

    private fun drawWheel(
        carX: Float, carY: Float, carZ: Float,
        carYawDeg: Float, carRollDeg: Float,
        localX: Float, localY: Float, localZ: Float,
        spinDeg: Float, steerDeg: Float
    ) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, carX, carY, carZ)
        Matrix.rotateM(modelMatrix, 0, carYawDeg, 0f, 1f, 0f)
        Matrix.rotateM(modelMatrix, 0, carRollDeg, 0f, 0f, 1f)
        Matrix.translateM(modelMatrix, 0, localX, localY, localZ)
        Matrix.rotateM(modelMatrix, 0, steerDeg, 0f, 1f, 0f)
        Matrix.rotateM(modelMatrix, 0, spinDeg, 1f, 0f, 0f)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)

        GLES20.glUniformMatrix4fv(worldShader.uModelMatrixLoc, 1, false, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(worldShader.uMvpMatrixLoc, 1, false, mvpMatrix, 0)
        GLES20.glUniform3f(worldShader.uColorTintLoc, 1f, 1f, 1f)
        GLES20.glUniform1f(worldShader.uSpecularStrengthLoc, 0.55f)
        wheelMesh.draw(worldShader)
    }

    private fun drawMeshAt(
        mesh: Mesh,
        x: Float,
        y: Float,
        z: Float,
        yawDeg: Float = 0f,
        scale: Float = 1f,
        tint: FloatArray? = null,
        specular: Float = 0.08f,
        emissive: Float = 0f
    ) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, x, y, z)
        if (yawDeg != 0f) Matrix.rotateM(modelMatrix, 0, yawDeg, 0f, 1f, 0f)
        if (scale != 1f) Matrix.scaleM(modelMatrix, 0, scale, scale, scale)
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)

        GLES20.glUniformMatrix4fv(worldShader.uModelMatrixLoc, 1, false, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(worldShader.uMvpMatrixLoc, 1, false, mvpMatrix, 0)
        if (tint != null) {
            GLES20.glUniform3fv(worldShader.uColorTintLoc, 1, tint, 0)
        } else {
            GLES20.glUniform3f(worldShader.uColorTintLoc, 1f, 1f, 1f)
        }
        GLES20.glUniform1f(worldShader.uSpecularStrengthLoc, specular)
        GLES20.glUniform1f(worldShader.uEmissiveBoostLoc, emissive)
        mesh.draw(worldShader)
    }

    private fun buildHeadlightConeMesh(): Mesh {
        val mb = MeshBuilder()
        val warmBeam = floatArrayOf(1.0f, 0.96f, 0.80f)
        // Left headlight cone on road
        mb.addTriangle(-0.62f, 0.04f, 2.2f, -2.5f, 0.04f, 26f, 0.4f, 0.04f, 26f, warmBeam[0], warmBeam[1], warmBeam[2])
        // Right headlight cone on road
        mb.addTriangle(0.62f, 0.04f, 2.2f, -0.4f, 0.04f, 26f, 2.5f, 0.04f, 26f, warmBeam[0], warmBeam[1], warmBeam[2])
        return mb.build()
    }

    private fun buildSceneryMeshes() {
        // Pine Tree
        pineTreeMesh = MeshBuilder().apply {
            addCylinderY(0f, 0f, 0f, 0.35f, 2.1f, 8, floatArrayOf(0.36f, 0.22f, 0.12f))
            addCone(0f, 1.8f, 0f, 1.9f, 3.0f, 9, floatArrayOf(0.11f, 0.36f, 0.14f))
            addCone(0f, 3.3f, 0f, 1.45f, 2.5f, 9, floatArrayOf(0.14f, 0.44f, 0.18f))
            addCone(0f, 4.6f, 0f, 0.95f, 2.0f, 9, floatArrayOf(0.16f, 0.50f, 0.20f))
        }.build()

        // Countryside Barn
        barnMesh = MeshBuilder().apply {
            addBox(0f, 0f, 0f, 5.2f, 3.4f, 6.4f, floatArrayOf(0.68f, 0.18f, 0.15f))
            addTaperedBox(0f, 3.4f, 0f, 5.6f, 6.6f, 0.4f, 6.6f, 1.8f, floatArrayOf(0.28f, 0.24f, 0.22f))
            addBox(0f, 0.9f, 3.22f, 1.8f, 1.8f, 0.08f, floatArrayOf(0.92f, 0.90f, 0.85f))
        }.build()

        // Modern Skyscrapers
        skyscraperTallMesh = buildSkyscraperMesh(7.5f, 26f, 7.5f, floatArrayOf(0.22f, 0.29f, 0.42f))
        skyscraperMidMesh = buildSkyscraperMesh(6.5f, 16f, 6.5f, floatArrayOf(0.26f, 0.34f, 0.46f))

        // Mountain Peak
        mountainPeakMesh = MeshBuilder().apply {
            addCone(0f, 0f, 0f, 12.5f, 19f, 7, floatArrayOf(0.38f, 0.40f, 0.45f))
            addCone(0f, 13.5f, 0f, 3.7f, 5.6f, 7, floatArrayOf(0.94f, 0.96f, 0.99f))
        }.build()

        // Coastal Palm Tree
        palmTreeMesh = MeshBuilder().apply {
            addCylinderY(0f, 0f, 0f, 0.24f, 5.2f, 8, floatArrayOf(0.48f, 0.36f, 0.24f))
            val frondRgb = floatArrayOf(0.16f, 0.58f, 0.20f)
            addBox(1.3f, 5.1f, 0f, 2.6f, 0.12f, 0.65f, frondRgb)
            addBox(-1.3f, 5.1f, 0f, 2.6f, 0.12f, 0.65f, frondRgb)
            addBox(0f, 5.1f, 1.3f, 0.65f, 0.12f, 2.6f, frondRgb)
            addBox(0f, 5.1f, -1.3f, 0.65f, 0.12f, 2.6f, frondRgb)
        }.build()

        // Desert Mesa
        desertMesaMesh = MeshBuilder().apply {
            addTaperedBox(0f, 0f, 0f, 16f, 16f, 9f, 9f, 9.5f, floatArrayOf(0.72f, 0.36f, 0.20f))
        }.build()

        // Saguaro Cactus
        cactusMesh = MeshBuilder().apply {
            val green = floatArrayOf(0.20f, 0.52f, 0.22f)
            addCylinderY(0f, 0f, 0f, 0.28f, 3.4f, 8, green)
            addBox(-0.65f, 1.6f, 0f, 1.1f, 0.36f, 0.36f, green)
            addBox(-1.05f, 1.6f, 0f, 0.36f, 1.2f, 0.36f, green)
            addBox(0.65f, 2.0f, 0f, 1.0f, 0.34f, 0.34f, green)
            addBox(0.98f, 2.0f, 0f, 0.34f, 1.1f, 0.34f, green)
        }.build()

        // Streetlamps (Left & Right)
        streetLampLeftMesh = buildStreetLampMesh(armDir = 1f)
        streetLampRightMesh = buildStreetLampMesh(armDir = -1f)

        // Overhead Highway Gantry
        highwayGantryMesh = MeshBuilder().apply {
            val steel = floatArrayOf(0.48f, 0.52f, 0.58f)
            addBox(-8.4f, 0f, 0f, 0.38f, 6.6f, 0.38f, steel)
            addBox(8.4f, 0f, 0f, 0.38f, 6.6f, 0.38f, steel)
            addBox(0f, 6.4f, 0f, 17.2f, 0.42f, 0.42f, steel)
            addBox(0f, 6.1f, 0f, 6.4f, 1.35f, 0.16f, floatArrayOf(0.08f, 0.45f, 0.28f))
        }.build()
    }

    private fun buildSkyscraperMesh(w: Float, h: Float, l: Float, baseRgb: FloatArray): Mesh {
        val mb = MeshBuilder()
        mb.addBox(0f, 0f, 0f, w, h, l, baseRgb)
        val winColor = floatArrayOf(0.86f, 0.90f, 0.98f)
        var y = 2.5f
        while (y < h - 1.5f) {
            mb.addBox(0f, y, 0f, w + 0.12f, 0.65f, l + 0.12f, winColor)
            y += 2.6f
        }
        return mb.build()
    }

    private fun buildStreetLampMesh(armDir: Float): Mesh {
        val mb = MeshBuilder()
        val pole = floatArrayOf(0.32f, 0.35f, 0.40f)
        val lampGlow = floatArrayOf(1.0f, 0.84f, 0.38f)
        mb.addBox(0f, 0f, 0f, 0.22f, 6.4f, 0.22f, pole)
        mb.addBox(armDir * 1.1f, 6.2f, 0f, 2.2f, 0.18f, 0.18f, pole)
        mb.addBox(armDir * 2.0f, 6.02f, 0f, 0.55f, 0.16f, 0.34f, lampGlow)
        return mb.build()
    }
}
