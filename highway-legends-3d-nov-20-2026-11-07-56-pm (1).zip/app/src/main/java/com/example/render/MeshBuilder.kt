package com.example.render

import com.example.model.CarSpec
import com.example.model.TrafficVehicleType
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class MeshBuilder {
    private val verts = ArrayList<Float>(4096)

    fun build(): Mesh = Mesh(verts.toFloatArray())

    fun addTriangle(
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        r: Float, g: Float, b: Float
    ) {
        val ux = x2 - x1; val uy = y2 - y1; val uz = z2 - z1
        val vx = x3 - x1; val vy = y3 - y1; val vz = z3 - z1
        var nx = uy * vz - uz * vy
        var ny = uz * vx - ux * vz
        var nz = ux * vy - uy * vx
        val len = sqrt(nx * nx + ny * ny + nz * nz)
        if (len > 1e-5f) {
            nx /= len; ny /= len; nz /= len
        } else {
            nx = 0f; ny = 1f; nz = 0f
        }
        pushVertex(x1, y1, z1, nx, ny, nz, r, g, b)
        pushVertex(x2, y2, z2, nx, ny, nz, r, g, b)
        pushVertex(x3, y3, z3, nx, ny, nz, r, g, b)
    }

    fun addQuad(
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        x4: Float, y4: Float, z4: Float,
        r: Float, g: Float, b: Float
    ) {
        addTriangle(x1, y1, z1, x2, y2, z2, x3, y3, z3, r, g, b)
        addTriangle(x1, y1, z1, x3, y3, z3, x4, y4, z4, r, g, b)
    }

    fun addBox(
        cx: Float, cy: Float, cz: Float,
        w: Float, h: Float, l: Float,
        rgb: FloatArray
    ) {
        addTaperedBox(cx, cy, cz, w, l, w, l, h, rgb)
    }

    fun addTaperedBox(
        cx: Float, cyBottom: Float, cz: Float,
        bottomW: Float, bottomL: Float,
        topW: Float, topL: Float,
        h: Float,
        rgb: FloatArray
    ) {
        val r = rgb[0]; val g = rgb[1]; val b = rgb[2]
        val bw = bottomW * 0.5f; val bl = bottomL * 0.5f
        val tw = topW * 0.5f; val tl = topL * 0.5f
        val y0 = cyBottom
        val y1 = cyBottom + h

        // Top
        addQuad(
            cx - tw, y1, cz + tl,
            cx + tw, y1, cz + tl,
            cx + tw, y1, cz - tl,
            cx - tw, y1, cz - tl,
            r, g, b
        )
        // Bottom
        addQuad(
            cx - bw, y0, cz - bl,
            cx + bw, y0, cz - bl,
            cx + bw, y0, cz + bl,
            cx - bw, y0, cz + bl,
            r * 0.6f, g * 0.6f, b * 0.6f
        )
        // Front (+Z)
        addQuad(
            cx - bw, y0, cz + bl,
            cx + bw, y0, cz + bl,
            cx + tw, y1, cz + tl,
            cx - tw, y1, cz + tl,
            r * 0.94f, g * 0.94f, b * 0.94f
        )
        // Back (-Z)
        addQuad(
            cx + bw, y0, cz - bl,
            cx - bw, y0, cz - bl,
            cx - tw, y1, cz - tl,
            cx + tw, y1, cz - tl,
            r * 0.90f, g * 0.90f, b * 0.90f
        )
        // Left (-X)
        addQuad(
            cx - bw, y0, cz - bl,
            cx - bw, y0, cz + bl,
            cx - tw, y1, cz + tl,
            cx - tw, y1, cz - tl,
            r * 0.96f, g * 0.96f, b * 0.96f
        )
        // Right (+X)
        addQuad(
            cx + bw, y0, cz + bl,
            cx + bw, y0, cz - bl,
            cx + tw, y1, cz - tl,
            cx + tw, y1, cz + tl,
            r * 0.96f, g * 0.96f, b * 0.96f
        )
    }

    fun addCone(
        cx: Float, cyBottom: Float, cz: Float,
        radius: Float, height: Float, segments: Int,
        rgb: FloatArray
    ) {
        val r = rgb[0]; val g = rgb[1]; val b = rgb[2]
        val step = (2.0 * PI / segments).toFloat()
        for (i in 0 until segments) {
            val a0 = i * step
            val a1 = (i + 1) * step
            val x0 = cx + cos(a0) * radius
            val z0 = cz + sin(a0) * radius
            val x1 = cx + cos(a1) * radius
            val z1 = cz + sin(a1) * radius
            addTriangle(x1, cyBottom, z1, x0, cyBottom, z0, cx, cyBottom + height, cz, r, g, b)
        }
    }

    fun addCylinderY(
        cx: Float, cyBottom: Float, cz: Float,
        radius: Float, height: Float, segments: Int,
        rgb: FloatArray
    ) {
        val r = rgb[0]; val g = rgb[1]; val b = rgb[2]
        val step = (2.0 * PI / segments).toFloat()
        for (i in 0 until segments) {
            val a0 = i * step
            val a1 = (i + 1) * step
            val x0 = cx + cos(a0) * radius
            val z0 = cz + sin(a0) * radius
            val x1 = cx + cos(a1) * radius
            val z1 = cz + sin(a1) * radius
            addQuad(
                x0, cyBottom, z0,
                x1, cyBottom, z1,
                x1, cyBottom + height, z1,
                x0, cyBottom + height, z0,
                r, g, b
            )
            addTriangle(cx, cyBottom + height, cz, x0, cyBottom + height, z0, x1, cyBottom + height, z1, r, g, b)
        }
    }

    fun addCylinderX(
        cx: Float, cy: Float, cz: Float,
        radius: Float, width: Float, segments: Int,
        rgb: FloatArray
    ) {
        val r = rgb[0]; val g = rgb[1]; val b = rgb[2]
        val halfW = width * 0.5f
        val step = (2.0 * PI / segments).toFloat()
        for (i in 0 until segments) {
            val a0 = i * step
            val a1 = (i + 1) * step
            val y0 = cy + cos(a0) * radius
            val z0 = cz + sin(a0) * radius
            val y1 = cy + cos(a1) * radius
            val z1 = cz + sin(a1) * radius
            addQuad(
                cx - halfW, y0, z0,
                cx + halfW, y0, z0,
                cx + halfW, y1, z1,
                cx - halfW, y1, z1,
                r, g, b
            )
            // Left cap
            addTriangle(cx - halfW, cy, cz, cx - halfW, y1, z1, cx - halfW, y0, z0, r * 0.85f, g * 0.85f, b * 0.85f)
            // Right cap
            addTriangle(cx + halfW, cy, cz, cx + halfW, y0, z0, cx + halfW, y1, z1, r * 0.85f, g * 0.85f, b * 0.85f)
        }
    }

    private fun pushVertex(
        x: Float, y: Float, z: Float,
        nx: Float, ny: Float, nz: Float,
        r: Float, g: Float, b: Float
    ) {
        verts.add(x); verts.add(y); verts.add(z)
        verts.add(nx); verts.add(ny); verts.add(nz)
        verts.add(r); verts.add(g); verts.add(b)
    }
}

object CarMeshFactory {
    private val CARBON_DARK = floatArrayOf(0.08f, 0.09f, 0.11f)
    private val GLASS_TINT = floatArrayOf(0.10f, 0.18f, 0.28f)
    private val CHROME = floatArrayOf(0.78f, 0.82f, 0.88f)
    private val HEADLIGHT_COLOR = floatArrayOf(1.0f, 0.96f, 0.82f)
    private val TAILLIGHT_COLOR = floatArrayOf(0.95f, 0.10f, 0.12f)

    fun buildWheelMesh(): Mesh {
        val mb = MeshBuilder()
        // Outer rubber tire
        mb.addCylinderX(0f, 0f, 0f, 0.34f, 0.26f, 16, floatArrayOf(0.10f, 0.10f, 0.12f))
        // Metallic alloy rim
        mb.addCylinderX(0f, 0f, 0f, 0.22f, 0.275f, 12, CHROME)
        // Spokes so spin is visibly crisp
        mb.addBox(0f, 0f, 0f, 0.285f, 0.38f, 0.06f, floatArrayOf(0.24f, 0.26f, 0.30f))
        mb.addBox(0f, 0f, 0f, 0.285f, 0.06f, 0.38f, floatArrayOf(0.24f, 0.26f, 0.30f))
        return mb.build()
    }

    fun buildSportsCarBodyMesh(spec: CarSpec, paintIndex: Int): Mesh {
        val paint = spec.paintOptions[paintIndex.coerceIn(0, spec.paintOptions.lastIndex)]
        val body = paint.bodyRgb
        val accent = paint.accentRgb
        val mb = MeshBuilder()

        val w = spec.width
        val l = spec.length
        val halfL = l * 0.5f

        // Underbody splitter & side skirts
        mb.addBox(0f, 0.14f, 0.04f, w * 0.98f, 0.10f, l * 0.98f, CARBON_DARK)
        // Front aerodynamic lip
        mb.addTaperedBox(0f, 0.12f, halfL - 0.14f, w * 0.96f, 0.32f, w * 0.90f, 0.22f, 0.11f, accent)

        // Main sculpted lower body
        mb.addTaperedBox(0f, 0.24f, 0f, w, l * 0.96f, w * 0.94f, l * 0.90f, 0.42f, body)

        // Hood stripe / racing livery
        mb.addBox(0f, 0.665f, halfL * 0.38f, 0.28f, 0.018f, l * 0.42f, accent)
        mb.addBox(0f, 0.665f, -halfL * 0.52f, 0.28f, 0.018f, l * 0.30f, accent)

        // Sculpted cabin / greenhouse (windshield + roof + fastback)
        mb.addTaperedBox(0f, 0.65f, -0.22f, w * 0.78f, l * 0.48f, w * 0.64f, l * 0.25f, spec.height - 0.66f, GLASS_TINT)
        // Painted roof cap
        mb.addTaperedBox(0f, spec.height - 0.05f, -0.26f, w * 0.62f, l * 0.24f, w * 0.58f, l * 0.20f, 0.06f, body)

        // Side mirrors
        mb.addBox(-w * 0.48f, 0.68f, 0.42f, 0.20f, 0.09f, 0.14f, body)
        mb.addBox(w * 0.48f, 0.68f, 0.42f, 0.20f, 0.09f, 0.14f, body)

        // Rear diffuser + twin chrome exhaust tips
        mb.addBox(0f, 0.18f, -halfL + 0.04f, w * 0.82f, 0.16f, 0.14f, CARBON_DARK)
        mb.addBox(-0.46f, 0.22f, -halfL - 0.04f, 0.13f, 0.08f, 0.14f, CHROME)
        mb.addBox(-0.28f, 0.22f, -halfL - 0.04f, 0.13f, 0.08f, 0.14f, CHROME)
        mb.addBox(0.28f, 0.22f, -halfL - 0.04f, 0.13f, 0.08f, 0.14f, CHROME)
        mb.addBox(0.46f, 0.22f, -halfL - 0.04f, 0.13f, 0.08f, 0.14f, CHROME)

        // Front headlights
        mb.addBox(-w * 0.34f, 0.45f, halfL - 0.02f, 0.36f, 0.10f, 0.10f, HEADLIGHT_COLOR)
        mb.addBox(w * 0.34f, 0.45f, halfL - 0.02f, 0.36f, 0.10f, 0.10f, HEADLIGHT_COLOR)

        // Optional GT Rear Wing
        if (spec.hasRearWing) {
            mb.addBox(-0.44f, 0.66f, -halfL + 0.24f, 0.06f, 0.24f, 0.20f, CARBON_DARK)
            mb.addBox(0.44f, 0.66f, -halfL + 0.24f, 0.06f, 0.24f, 0.20f, CARBON_DARK)
            mb.addBox(0f, 0.90f, -halfL + 0.20f, w * 0.94f, 0.06f, 0.30f, CARBON_DARK)
            mb.addBox(-w * 0.47f, 0.86f, -halfL + 0.20f, 0.04f, 0.16f, 0.32f, accent)
            mb.addBox(w * 0.47f, 0.86f, -halfL + 0.20f, 0.04f, 0.16f, 0.32f, accent)
        }

        // Optional Roof Intake Scoop
        if (spec.hasRoofScoop) {
            mb.addTaperedBox(0f, spec.height, -0.18f, 0.34f, 0.56f, 0.24f, 0.42f, 0.11f, CARBON_DARK)
        }

        return mb.build()
    }

    fun buildTailLightBarMesh(spec: CarSpec): Mesh {
        val mb = MeshBuilder()
        val w = spec.width
        val halfL = spec.length * 0.5f
        mb.addBox(-w * 0.34f, 0.52f, -halfL + 0.02f, 0.42f, 0.09f, 0.08f, TAILLIGHT_COLOR)
        mb.addBox(w * 0.34f, 0.52f, -halfL + 0.02f, 0.42f, 0.09f, 0.08f, TAILLIGHT_COLOR)
        mb.addBox(0f, 0.53f, -halfL + 0.01f, w * 0.42f, 0.035f, 0.06f, TAILLIGHT_COLOR)
        return mb.build()
    }

    fun buildTrafficMesh(type: TrafficVehicleType): Mesh {
        val mb = MeshBuilder()
        val w = type.width
        val l = type.length
        val h = type.height
        val halfL = l * 0.5f

        when (type) {
            TrafficVehicleType.BOX_TRUCK -> {
                // Cab
                mb.addBox(0f, 0.35f, halfL - 1.15f, w * 0.94f, 1.75f, 2.0f, floatArrayOf(0.88f, 0.88f, 0.92f))
                mb.addBox(0f, 1.35f, halfL - 0.16f, w * 0.84f, 0.65f, 0.08f, GLASS_TINT)
                // Tall cargo box
                mb.addBox(0f, 0.62f, -1.05f, w, h - 0.62f, l - 2.35f, floatArrayOf(0.95f, 0.95f, 0.97f))
                // Rear bumper & taillights
                mb.addBox(0f, 0.34f, -halfL, w * 0.96f, 0.22f, 0.18f, CARBON_DARK)
                mb.addBox(-w * 0.38f, 0.55f, -halfL - 0.02f, 0.28f, 0.14f, 0.06f, TAILLIGHT_COLOR)
                mb.addBox(w * 0.38f, 0.55f, -halfL - 0.02f, 0.28f, 0.14f, 0.06f, TAILLIGHT_COLOR)
                // 4 wheels
                val wx = w * 0.46f
                mb.addCylinderX(-wx, 0.38f, halfL - 1.1f, 0.38f, 0.28f, 12, CARBON_DARK)
                mb.addCylinderX(wx, 0.38f, halfL - 1.1f, 0.38f, 0.28f, 12, CARBON_DARK)
                mb.addCylinderX(-wx, 0.38f, -halfL + 1.3f, 0.38f, 0.28f, 12, CARBON_DARK)
                mb.addCylinderX(wx, 0.38f, -halfL + 1.3f, 0.38f, 0.28f, 12, CARBON_DARK)
            }

            TrafficVehicleType.PICKUP -> {
                mb.addBox(0f, 0.32f, 0f, w, 0.68f, l, floatArrayOf(1f, 1f, 1f))
                // Cab
                mb.addTaperedBox(0f, 1.00f, 0.45f, w * 0.84f, 1.95f, w * 0.74f, 1.45f, 0.68f, GLASS_TINT)
                mb.addBox(0f, 1.66f, 0.40f, w * 0.72f, 0.06f, 1.40f, floatArrayOf(1f, 1f, 1f))
                // Truck bed recessed dark liner
                mb.addBox(0f, 0.98f, -1.30f, w * 0.80f, 0.05f, 1.75f, CARBON_DARK)
                addTrafficWheelsAndLights(mb, w, l, 0.36f)
            }

            TrafficVehicleType.SUV -> {
                mb.addTaperedBox(0f, 0.30f, 0f, w, l, w * 0.95f, l * 0.94f, 0.68f, floatArrayOf(1f, 1f, 1f))
                mb.addTaperedBox(0f, 0.98f, -0.25f, w * 0.84f, l * 0.68f, w * 0.74f, l * 0.56f, 0.66f, GLASS_TINT)
                mb.addBox(0f, 1.62f, -0.28f, w * 0.72f, 0.06f, l * 0.54f, floatArrayOf(1f, 1f, 1f))
                addTrafficWheelsAndLights(mb, w, l, 0.35f)
            }

            TrafficVehicleType.SPORTS_TRAFFIC -> {
                mb.addTaperedBox(0f, 0.22f, 0f, w, l, w * 0.94f, l * 0.90f, 0.44f, floatArrayOf(1f, 1f, 1f))
                mb.addTaperedBox(0f, 0.66f, -0.18f, w * 0.78f, l * 0.46f, w * 0.64f, l * 0.26f, 0.52f, GLASS_TINT)
                mb.addBox(0f, 1.16f, -0.20f, w * 0.62f, 0.05f, l * 0.24f, floatArrayOf(1f, 1f, 1f))
                addTrafficWheelsAndLights(mb, w, l, 0.32f)
            }

            TrafficVehicleType.SEDAN -> {
                mb.addTaperedBox(0f, 0.25f, 0f, w, l, w * 0.94f, l * 0.92f, 0.55f, floatArrayOf(1f, 1f, 1f))
                mb.addTaperedBox(0f, 0.80f, -0.10f, w * 0.82f, l * 0.54f, w * 0.70f, l * 0.38f, 0.54f, GLASS_TINT)
                mb.addBox(0f, 1.32f, -0.10f, w * 0.68f, 0.05f, l * 0.36f, floatArrayOf(1f, 1f, 1f))
                addTrafficWheelsAndLights(mb, w, l, 0.32f)
            }
        }
        return mb.build()
    }

    private fun addTrafficWheelsAndLights(mb: MeshBuilder, w: Float, l: Float, wheelRadius: Float) {
        val halfL = l * 0.5f
        val wx = w * 0.46f
        val wz = l * 0.31f
        mb.addCylinderX(-wx, wheelRadius, wz, wheelRadius, 0.24f, 12, CARBON_DARK)
        mb.addCylinderX(wx, wheelRadius, wz, wheelRadius, 0.24f, 12, CARBON_DARK)
        mb.addCylinderX(-wx, wheelRadius, -wz, wheelRadius, 0.24f, 12, CARBON_DARK)
        mb.addCylinderX(wx, wheelRadius, -wz, wheelRadius, 0.24f, 12, CARBON_DARK)
        // Taillights
        mb.addBox(-w * 0.34f, 0.56f, -halfL + 0.02f, 0.34f, 0.10f, 0.06f, TAILLIGHT_COLOR)
        mb.addBox(w * 0.34f, 0.56f, -halfL + 0.02f, 0.34f, 0.10f, 0.06f, TAILLIGHT_COLOR)
        // Headlights
        mb.addBox(-w * 0.34f, 0.54f, halfL - 0.02f, 0.30f, 0.09f, 0.06f, HEADLIGHT_COLOR)
        mb.addBox(w * 0.34f, 0.54f, halfL - 0.02f, 0.30f, 0.09f, 0.06f, HEADLIGHT_COLOR)
    }
}
