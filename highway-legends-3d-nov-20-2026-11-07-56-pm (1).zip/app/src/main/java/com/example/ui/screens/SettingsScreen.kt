package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.SoundSettings
import com.example.model.SteeringMode
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonElevated
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.RacingAmber
import com.example.ui.theme.RacingCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    soundSettings: SoundSettings,
    onUpdateSettings: ((SoundSettings) -> SoundSettings) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CarbonBlack.copy(alpha = 0.86f))
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 24.dp, vertical = 14.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top bar
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = CarbonSurface,
                        contentColor = TextPrimary
                    ),
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("settings_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.action_back)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = stringResource(R.string.label_sound_settings),
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Audio Panel
                Surface(
                    color = CarbonSurface.copy(alpha = 0.92f),
                    border = BorderStroke(1.dp, CarbonBorder),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = null,
                                    tint = RacingAmber
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = stringResource(R.string.label_master_sound),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                            }
                            Switch(
                                checked = soundSettings.soundEnabled,
                                onCheckedChange = { enabled ->
                                    onUpdateSettings { it.copy(soundEnabled = enabled) }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = CarbonBlack,
                                    checkedTrackColor = RacingAmber
                                ),
                                modifier = Modifier.testTag("sound_master_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "${stringResource(R.string.label_engine_volume)}: ${(soundSettings.engineVolume * 100).toInt()}%",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Slider(
                            value = soundSettings.engineVolume,
                            enabled = soundSettings.soundEnabled,
                            onValueChange = { vol ->
                                onUpdateSettings { it.copy(engineVolume = vol) }
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = RacingAmber,
                                activeTrackColor = RacingAmber
                            ),
                            modifier = Modifier.testTag("engine_volume_slider")
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${stringResource(R.string.label_sfx_volume)}: ${(soundSettings.sfxVolume * 100).toInt()}%",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Slider(
                            value = soundSettings.sfxVolume,
                            enabled = soundSettings.soundEnabled,
                            onValueChange = { vol ->
                                onUpdateSettings { it.copy(sfxVolume = vol) }
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = RacingCyan,
                                activeTrackColor = RacingCyan
                            ),
                            modifier = Modifier.testTag("sfx_volume_slider")
                        )
                    }
                }

                // Controls & Monetization Readiness Panel
                Surface(
                    color = CarbonSurface.copy(alpha = 0.92f),
                    border = BorderStroke(1.dp, CarbonBorder),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = stringResource(R.string.label_steering_mode),
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val isTouch = soundSettings.steeringMode == SteeringMode.TOUCH
                            OutlinedButton(
                                onClick = {
                                    onUpdateSettings { it.copy(steeringMode = SteeringMode.TOUCH) }
                                },
                                border = BorderStroke(
                                    width = if (isTouch) 2.dp else 1.dp,
                                    color = if (isTouch) RacingAmber else CarbonBorder
                                ),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isTouch) CarbonElevated else CarbonSurface,
                                    contentColor = if (isTouch) RacingAmber else TextPrimary
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("steering_touch_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.TouchApp,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = stringResource(R.string.steering_touch),
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    onUpdateSettings { it.copy(steeringMode = SteeringMode.TILT) }
                                },
                                border = BorderStroke(
                                    width = if (!isTouch) 2.dp else 1.dp,
                                    color = if (!isTouch) RacingCyan else CarbonBorder
                                ),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (!isTouch) CarbonElevated else CarbonSurface,
                                    contentColor = if (!isTouch) RacingCyan else TextPrimary
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("steering_tilt_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.ScreenRotation,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Tilt",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Surface(
                            color = CarbonElevated,
                            border = BorderStroke(1.dp, CarbonBorder),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "OFFLINE PLAY & MONETIZATION MODULE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = RacingAmber
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "All progress saves locally on-device. AdMob Banner, Interstitial, and Rewarded slots are modularly wired in Test-Safe mode with zero live ads shown.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
