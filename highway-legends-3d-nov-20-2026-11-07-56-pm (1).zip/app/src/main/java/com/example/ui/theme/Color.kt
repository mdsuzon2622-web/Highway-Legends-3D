package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CarbonBlack = Color(0xFF080B12)
val CarbonSurface = Color(0xFF111622)
val CarbonElevated = Color(0xFF1A2233)
val CarbonBorder = Color(0xFF2B364D)

val RacingCrimson = Color(0xFFE63946)
val RacingAmber = Color(0xFFFFB703)
val RacingCyan = Color(0xFF00E5FF)
val RacingEmerald = Color(0xFF10B981)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
