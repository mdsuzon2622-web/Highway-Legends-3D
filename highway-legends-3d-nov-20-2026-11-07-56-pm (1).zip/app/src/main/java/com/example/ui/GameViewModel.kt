package com.example.ui

import android.app.Activity
import android.app.Application
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GameProgressRepository
import com.example.engine.GamePhysicsEngine
import com.example.engine.HudTelemetry
import com.example.engine.ProceduralAudioEngine
import com.example.model.CameraMode
import com.example.model.CarCatalog
import com.example.model.EnvironmentId
import com.example.model.GameScreen
import com.example.model.PlayerProgress
import com.example.model.SoundSettings
import com.example.model.SteeringMode
import com.example.monetization.AdProvider
import com.example.monetization.OfflineTestAdProvider
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

data class GameUiState(
    val screen: GameScreen = GameScreen.MAIN_MENU,
    val progress: PlayerProgress = PlayerProgress(),
    val soundSettings: SoundSettings = SoundSettings(),
    val telemetry: HudTelemetry = HudTelemetry(),
    val isNewRecord: Boolean = false,
    val leftSteerHeld: Boolean = false,
    val rightSteerHeld: Boolean = false,
    val gasHeld: Boolean = false,
    val brakeHeld: Boolean = false,
    val tiltSteerValue: Float = 0f
)

class GameViewModel(application: Application) : AndroidViewModel(application), SensorEventListener {

    private val repository = GameProgressRepository(application)
    val physicsEngine = GamePhysicsEngine()
    val audioEngine = ProceduralAudioEngine()
    val adProvider: AdProvider = OfflineTestAdProvider()

    private val sensorManager = application.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var raceLoopJob: Job? = null
    private var lastNearMissCount = 0

    init {
        adProvider.initialize()
        audioEngine.start()

        viewModelScope.launch {
            repository.progressFlow.collect { progress ->
                val car = CarCatalog.byId(progress.selectedCarId)
                physicsEngine.configureCar(car, progress.selectedPaintIndex)
                _uiState.update { it.copy(progress = progress) }
            }
        }

        viewModelScope.launch {
            repository.soundSettingsFlow.collect { settings ->
                audioEngine.updateSettings(settings)
                _uiState.update { it.copy(soundSettings = settings) }
                updateSensorRegistration()
            }
        }
    }

    fun startRace() {
        val progress = _uiState.value.progress
        val car = CarCatalog.byId(progress.selectedCarId)
        lastNearMissCount = 0
        physicsEngine.startNewRace(car, progress.selectedPaintIndex)
        adProvider.loadInterstitial()

        _uiState.update {
            it.copy(
                screen = GameScreen.PLAYING,
                isNewRecord = false,
                leftSteerHeld = false,
                rightSteerHeld = false,
                gasHeld = false,
                brakeHeld = false,
                telemetry = physicsEngine.getHudTelemetry()
            )
        }
        updateSensorRegistration()
        startRaceLoop()
    }

    fun pauseRace() {
        if (_uiState.value.screen != GameScreen.PLAYING) return
        stopRaceLoop()
        clearTouchInputs()
        audioEngine.updateTelemetry(0.2f, braking = false, racing = false)
        _uiState.update { it.copy(screen = GameScreen.PAUSED) }
        updateSensorRegistration()
    }

    fun resumeRace() {
        if (_uiState.value.screen != GameScreen.PAUSED) return
        _uiState.update { it.copy(screen = GameScreen.PLAYING) }
        updateSensorRegistration()
        startRaceLoop()
    }

    fun restartRace() {
        stopRaceLoop()
        startRace()
    }

    fun navigateTo(target: GameScreen) {
        stopRaceLoop()
        clearTouchInputs()
        audioEngine.updateTelemetry(0.2f, braking = false, racing = false)
        _uiState.update { it.copy(screen = target) }
        updateSensorRegistration()
    }

    fun handleBackPress(): Boolean {
        return when (_uiState.value.screen) {
            GameScreen.PLAYING -> {
                pauseRace()
                true
            }
            GameScreen.PAUSED -> {
                resumeRace()
                true
            }
            GameScreen.GAME_OVER,
            GameScreen.GARAGE,
            GameScreen.ENVIRONMENTS,
            GameScreen.SETTINGS -> {
                navigateTo(GameScreen.MAIN_MENU)
                true
            }
            GameScreen.MAIN_MENU -> false
        }
    }

    fun selectCar(carId: String, paintIndex: Int = 0) {
        val car = CarCatalog.byId(carId)
        val clampedPaint = paintIndex.coerceIn(0, car.paintOptions.lastIndex)
        physicsEngine.configureCar(car, clampedPaint)
        viewModelScope.launch {
            repository.saveSelectedCar(car.id, clampedPaint)
        }
    }

    fun selectEnvironment(envId: EnvironmentId) {
        viewModelScope.launch {
            repository.saveSelectedEnvironment(envId)
        }
    }

    fun cycleCameraMode(): CameraMode {
        val mode = physicsEngine.cycleCameraMode()
        _uiState.update { it.copy(telemetry = it.telemetry.copy(cameraMode = mode)) }
        return mode
    }

    fun setLeftSteerHeld(held: Boolean) {
        _uiState.update { it.copy(leftSteerHeld = held) }
        pushControlsToPhysics()
    }

    fun setRightSteerHeld(held: Boolean) {
        _uiState.update { it.copy(rightSteerHeld = held) }
        pushControlsToPhysics()
    }

    fun setGasHeld(held: Boolean) {
        _uiState.update { it.copy(gasHeld = held) }
        pushControlsToPhysics()
    }

    fun setBrakeHeld(held: Boolean) {
        _uiState.update { it.copy(brakeHeld = held) }
        pushControlsToPhysics()
    }

    fun updateSoundSettings(transform: (SoundSettings) -> SoundSettings) {
        val updated = transform(_uiState.value.soundSettings)
        audioEngine.updateSettings(updated)
        _uiState.update { it.copy(soundSettings = updated) }
        updateSensorRegistration()
        viewModelScope.launch {
            repository.saveSoundSettings(updated)
        }
    }

    fun showPostCrashInterstitialIfReady(activity: Activity?, onContinue: () -> Unit) {
        adProvider.showInterstitial(activity, onContinue)
    }

    private fun clearTouchInputs() {
        _uiState.update {
            it.copy(
                leftSteerHeld = false,
                rightSteerHeld = false,
                gasHeld = false,
                brakeHeld = false,
                tiltSteerValue = 0f
            )
        }
        physicsEngine.setControls(0f, 0f, 0f)
    }

    private fun pushControlsToPhysics() {
        val s = _uiState.value
        val steer = if (s.soundSettings.steeringMode == SteeringMode.TILT) {
            s.tiltSteerValue
        } else {
            (if (s.leftSteerHeld) -1f else 0f) + (if (s.rightSteerHeld) 1f else 0f)
        }
        val throttle = if (s.gasHeld) 1f else 0f
        val brake = if (s.brakeHeld) 1f else 0f
        physicsEngine.setControls(steer, throttle, brake)
    }

    private fun startRaceLoop() {
        raceLoopJob?.cancel()
        raceLoopJob = viewModelScope.launch {
            var lastNanos = System.nanoTime()
            while (isActive && _uiState.value.screen == GameScreen.PLAYING) {
                val now = System.nanoTime()
                val dt = ((now - lastNanos) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                lastNanos = now

                pushControlsToPhysics()
                val crashedNow = physicsEngine.stepRace(dt)
                val telemetry = physicsEngine.getHudTelemetry()

                if (telemetry.nearMissCount > lastNearMissCount) {
                    lastNearMissCount = telemetry.nearMissCount
                    audioEngine.triggerNearMiss()
                }

                audioEngine.updateTelemetry(
                    rpm = telemetry.rpmNormalized,
                    braking = _uiState.value.brakeHeld && telemetry.speedKmh > 12,
                    racing = !telemetry.hasCrashed
                )

                _uiState.update { it.copy(telemetry = telemetry) }

                if (crashedNow) {
                    audioEngine.triggerCrash()
                    val envId = _uiState.value.progress.selectedEnvironmentId
                    val newRecord = repository.recordRunResult(envId, telemetry.distanceMeters)
                    delay(650L) // Brief crash impact moment before showing summary
                    _uiState.update {
                        it.copy(
                            screen = GameScreen.GAME_OVER,
                            isNewRecord = newRecord
                        )
                    }
                    updateSensorRegistration()
                    break
                }

                delay(16L)
            }
        }
    }

    private fun stopRaceLoop() {
        raceLoopJob?.cancel()
        raceLoopJob = null
    }

    private fun updateSensorRegistration() {
        val shouldListen = _uiState.value.screen == GameScreen.PLAYING &&
            _uiState.value.soundSettings.steeringMode == SteeringMode.TILT
        sensorManager?.unregisterListener(this)
        if (shouldListen && accelerometer != null) {
            sensorManager?.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type != Sensor.TYPE_ACCELEROMETER) return
        // In landscape orientation, event.values[1] tilts left (-) / right (+)
        val rawTilt = event.values[1] / 4.2f
        val deadzone = if (abs(rawTilt) < 0.08f) 0f else rawTilt.coerceIn(-1f, 1f)
        _uiState.update { it.copy(tiltSteerValue = deadzone) }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onCleared() {
        super.onCleared()
        stopRaceLoop()
        sensorManager?.unregisterListener(this)
        audioEngine.stop()
    }
}
