package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.CarCatalog
import com.example.model.CarSpec
import com.example.model.PlayerProgress
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonElevated
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.RacingAmber
import com.example.ui.theme.RacingCyan
import com.example.ui.theme.RacingEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GarageScreen(
    progress: PlayerProgress,
    onSelectCar: (String, Int) -> Unit,
    onStartRace: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeCar = CarCatalog.byId(progress.selectedCarId)
    val activePaintIdx = progress.selectedPaintIndex.coerceIn(0, activeCar.paintOptions.lastIndex)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        CarbonBlack.copy(alpha = 0.90f),
                        CarbonBlack.copy(alpha = 0.45f),
                        Color.Transparent
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Car Selection List
            Column(
                modifier = Modifier
                    .width(290.dp)
                    .fillMaxHeight()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onBack,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = CarbonSurface.copy(alpha = 0.85f),
                            contentColor = TextPrimary
                        ),
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("garage_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = stringResource(R.string.action_garage),
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(CarCatalog.all, key = { it.id }) { car ->
                        val isSelected = car.id == activeCar.id
                        CarListItemCard(
                            car = car,
                            isSelected = isSelected,
                            onClick = { onSelectCar(car.id, 0) }
                        )
                    }
                }
            }

            // Right-Bottom: Selected Car Specs, Paint Swatches & Race CTA
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(310.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.End
            ) {
                Surface(
                    color = CarbonSurface.copy(alpha = 0.88f),
                    border = BorderStroke(1.dp, CarbonBorder),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = activeCar.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = RacingAmber
                        )
                        Text(
                            text = activeCar.name.uppercase(),
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = activeCar.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        CarStatBar(
                            label = "TOP SPEED",
                            valueText = "${activeCar.topSpeedKmh.toInt()} KM/H",
                            progress = (activeCar.topSpeedKmh / 350f).coerceIn(0f, 1f),
                            color = RacingAmber
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        CarStatBar(
                            label = "ACCELERATION",
                            valueText = "${((activeCar.accelerationRate / 34f) * 100).toInt()}%",
                            progress = (activeCar.accelerationRate / 34f).coerceIn(0f, 1f),
                            color = RacingCyan
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        CarStatBar(
                            label = "HANDLING",
                            valueText = "${((activeCar.handlingSpeed / 9.5f) * 100).toInt()}%",
                            progress = (activeCar.handlingSpeed / 9.5f).coerceIn(0f, 1f),
                            color = RacingEmerald
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "FACTORY PAINT",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            activeCar.paintOptions.forEachIndexed { idx, paint ->
                                val selectedSwatch = idx == activePaintIdx
                                Surface(
                                    color = Color(paint.previewHex),
                                    shape = CircleShape,
                                    border = BorderStroke(
                                        width = if (selectedSwatch) 3.dp else 1.dp,
                                        color = if (selectedSwatch) RacingAmber else CarbonBorder
                                    ),
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clickable { onSelectCar(activeCar.id, idx) }
                                        .testTag("paint_swatch_${activeCar.id}_$idx")
                                ) {
                                    if (selectedSwatch) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Filled.Check,
                                                contentDescription = paint.name,
                                                tint = CarbonBlack,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = onStartRace,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = RacingAmber,
                                contentColor = CarbonBlack
                            ),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(vertical = 12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("garage_race_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = stringResource(R.string.action_drive),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CarListItemCard(
    car: CarSpec,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = if (isSelected) CarbonElevated.copy(alpha = 0.94f) else CarbonSurface.copy(alpha = 0.80f),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) RacingAmber else CarbonBorder
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("car_card_${car.id}")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = car.name,
                    style = MaterialTheme.typography.titleLarge,
                    color = if (isSelected) RacingAmber else TextPrimary
                )
                Text(
                    text = "${car.category} • ${car.topSpeedKmh.toInt()} KM/H",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
            if (isSelected) {
                Icon(
                    imageVector = Icons.Filled.Check,
                    contentDescription = stringResource(R.string.action_selected),
                    tint = RacingAmber
                )
            }
        }
    }
}

@Composable
private fun CarStatBar(
    label: String,
    valueText: String,
    progress: Float,
    color: Color
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            Text(text = valueText, style = MaterialTheme.typography.labelSmall, color = TextPrimary)
        }
        Spacer(modifier = Modifier.height(3.dp))
        LinearProgressIndicator(
            progress = { progress },
            color = color,
            trackColor = CarbonBorder,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
        )
    }
}
