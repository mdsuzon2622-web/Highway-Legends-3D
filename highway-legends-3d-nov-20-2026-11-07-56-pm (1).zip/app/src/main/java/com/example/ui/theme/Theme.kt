package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val HighwayDarkColorScheme = darkColorScheme(
    primary = RacingAmber,
    onPrimary = CarbonBlack,
    secondary = RacingCyan,
    onSecondary = CarbonBlack,
    tertiary = RacingCrimson,
    onTertiary = TextPrimary,
    background = CarbonBlack,
    onBackground = TextPrimary,
    surface = CarbonSurface,
    onSurface = TextPrimary,
    surfaceVariant = CarbonElevated,
    onSurfaceVariant = TextSecondary,
    outline = CarbonBorder,
    error = RacingCrimson,
    onError = TextPrimary
)

@Composable
fun HighwayLegendsTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = HighwayDarkColorScheme,
        typography = HighwayTypography,
        content = content
    )
}
