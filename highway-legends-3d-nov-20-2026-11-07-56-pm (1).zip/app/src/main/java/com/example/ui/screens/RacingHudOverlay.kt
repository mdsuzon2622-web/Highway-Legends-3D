package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.engine.HudTelemetry
import com.example.model.EnvironmentCatalog
import com.example.model.EnvironmentId
import com.example.model.SteeringMode
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.RacingAmber
import com.example.ui.theme.RacingCrimson
import com.example.ui.theme.RacingCyan
import com.example.ui.theme.RacingEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun RacingHudOverlay(
    telemetry: HudTelemetry,
    environmentId: EnvironmentId,
    steeringMode: SteeringMode,
    leftHeld: Boolean,
    rightHeld: Boolean,
    gasHeld: Boolean,
    brakeHeld: Boolean,
    tiltSteerValue: Float,
    onLeftHeldChange: (Boolean) -> Unit,
    onRightHeldChange: (Boolean) -> Unit,
    onGasHeldChange: (Boolean) -> Unit,
    onBrakeHeldChange: (Boolean) -> Unit,
    onCycleCamera: () -> Unit,
    onPause: () -> Unit,
    modifier: Modifier = Modifier
) {
    val env = EnvironmentCatalog.byId(environmentId)

    Box(
        modifier = modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 18.dp, vertical = 12.dp)
    ) {
        // Top HUD Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.Top
        ) {
            // Top-Left: Speedometer & RPM & Gear
            Surface(
                color = CarbonBlack.copy(alpha = 0.74f),
                border = BorderStroke(1.dp, CarbonBorder),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("speedometer_panel")
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = telemetry.speedKmh.toString(),
                            style = MaterialTheme.typography.displayMedium.copy(fontSize = 36.sp),
                            color = if (telemetry.speedKmh > 240) RacingAmber else TextPrimary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(modifier = Modifier.padding(bottom = 4.dp)) {
                            Text(
                                text = stringResource(R.string.label_speed_unit),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                            Text(
                                text = "G${telemetry.gear}",
                                style = MaterialTheme.typography.labelLarge,
                                color = RacingCyan
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { telemetry.rpmNormalized },
                        color = if (telemetry.rpmNormalized > 0.85f) RacingCrimson else RacingAmber,
                        trackColor = CarbonBorder,
                        modifier = Modifier
                            .width(136.dp)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                    )
                }
            }

            // Top-Center: Distance Counter & Environment Badge + Near Miss Toast
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    color = CarbonBlack.copy(alpha = 0.74f),
                    border = BorderStroke(1.dp, CarbonBorder),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("distance_panel")
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = formatDistance(telemetry.distanceMeters),
                            style = MaterialTheme.typography.headlineMedium,
                            color = RacingAmber
                        )
                        Text(
                            text = env.title.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            maxLines = 1
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                AnimatedVisibility(
                    visible = telemetry.showNearMissBanner,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Surface(
                        color = RacingCyan.copy(alpha = 0.90f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "NEAR MISS! (${telemetry.nearMissCount})",
                            style = MaterialTheme.typography.labelLarge,
                            color = CarbonBlack,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Top-Right: Camera Switch + Pause
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    onClick = onCycleCamera,
                    color = CarbonBlack.copy(alpha = 0.76f),
                    border = BorderStroke(1.dp, CarbonBorder),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("camera_switch_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Cameraswitch,
                            contentDescription = stringResource(R.string.cd_camera),
                            tint = RacingCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = telemetry.cameraMode.label,
                            style = MaterialTheme.typography.labelLarge,
                            color = TextPrimary
                        )
                    }
                }

                IconButton(
                    onClick = onPause,
                    colors = IconButtonDefaults.iconButtonColors(
                        containerColor = CarbonBlack.copy(alpha = 0.78f),
                        contentColor = TextPrimary
                    ),
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("pause_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Pause,
                        contentDescription = stringResource(R.string.cd_pause),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        // Bottom Controls Row (Multi-touch holdable Steering + Brake/Gas Pedals)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            // Bottom-Left: Steering Controls
            if (steeringMode == SteeringMode.TOUCH) {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    HoldableSteerButton(
                        icon = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                        contentDescription = stringResource(R.string.cd_steer_left),
                        isPressed = leftHeld,
                        onPressedChange = onLeftHeldChange,
                        modifier = Modifier.testTag("steer_left_button")
                    )
                    HoldableSteerButton(
                        icon = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = stringResource(R.string.cd_steer_right),
                        isPressed = rightHeld,
                        onPressedChange = onRightHeldChange,
                        modifier = Modifier.testTag("steer_right_button")
                    )
                }
            } else {
                Surface(
                    color = CarbonBlack.copy(alpha = 0.65f),
                    border = BorderStroke(1.dp, CarbonBorder),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ScreenRotation,
                            contentDescription = null,
                            tint = RacingCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "TILT STEER ${(tiltSteerValue * 100).toInt()}%",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextPrimary
                        )
                    }
                }
            }

            // Bottom-Right: Brake & Gas Pedals
            Row(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                HoldablePedalButton(
                    label = "BRAKE",
                    accentColor = RacingCrimson,
                    isPressed = brakeHeld,
                    onPressedChange = onBrakeHeldChange,
                    widthDp = 88,
                    heightDp = 74,
                    modifier = Modifier.testTag("brake_button")
                )
                HoldablePedalButton(
                    label = "GAS",
                    accentColor = RacingEmerald,
                    isPressed = gasHeld,
                    onPressedChange = onGasHeldChange,
                    widthDp = 96,
                    heightDp = 104,
                    modifier = Modifier.testTag("accelerate_button")
                )
            }
        }
    }
}

@Composable
private fun HoldableSteerButton(
    icon: ImageVector,
    contentDescription: String,
    isPressed: Boolean,
    onPressedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (isPressed) RacingAmber.copy(alpha = 0.90f) else CarbonSurface.copy(alpha = 0.72f),
        border = BorderStroke(
            width = if (isPressed) 2.dp else 1.5.dp,
            color = if (isPressed) RacingAmber else CarbonBorder
        ),
        shape = CircleShape,
        modifier = modifier
            .size(74.dp)
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    onPressedChange(true)
                    try {
                        waitForUpOrCancellation()
                    } finally {
                        onPressedChange(false)
                    }
                }
            }
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = if (isPressed) CarbonBlack else TextPrimary,
                modifier = Modifier.size(38.dp)
            )
        }
    }
}

@Composable
private fun HoldablePedalButton(
    label: String,
    accentColor: Color,
    isPressed: Boolean,
    onPressedChange: (Boolean) -> Unit,
    widthDp: Int,
    heightDp: Int,
    modifier: Modifier = Modifier
) {
    Surface(
        color = if (isPressed) accentColor.copy(alpha = 0.88f) else CarbonSurface.copy(alpha = 0.74f),
        border = BorderStroke(
            width = if (isPressed) 2.dp else 1.5.dp,
            color = accentColor.copy(alpha = if (isPressed) 1f else 0.75f)
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .size(width = widthDp.dp, height = heightDp.dp)
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    onPressedChange(true)
                    try {
                        waitForUpOrCancellation()
                    } finally {
                        onPressedChange(false)
                    }
                }
            }
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Transparent)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.titleLarge,
                color = if (isPressed) CarbonBlack else TextPrimary,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
