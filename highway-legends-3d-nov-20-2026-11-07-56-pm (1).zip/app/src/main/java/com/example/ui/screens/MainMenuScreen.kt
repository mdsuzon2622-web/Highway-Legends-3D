package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Landscape
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CarCatalog
import com.example.model.EnvironmentCatalog
import com.example.model.PlayerProgress
import com.example.monetization.AdPlacement
import com.example.monetization.AdProvider
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.RacingAmber
import com.example.ui.theme.RacingCrimson
import com.example.ui.theme.RacingCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MainMenuScreen(
    progress: PlayerProgress,
    adProvider: AdProvider,
    onStartRace: () -> Unit,
    onOpenGarage: () -> Unit,
    onOpenEnvironments: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedCar = CarCatalog.byId(progress.selectedCarId)
    val selectedEnv = EnvironmentCatalog.byId(progress.selectedEnvironmentId)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        CarbonBlack.copy(alpha = 0.92f),
                        CarbonBlack.copy(alpha = 0.72f),
                        Color.Transparent
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 24.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Column: Brand Header + Primary Actions
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(1f, fill = false)
                    .width(340.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Surface(
                        color = RacingCrimson.copy(alpha = 0.18f),
                        border = BorderStroke(1.dp, RacingCrimson.copy(alpha = 0.65f)),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.tagline),
                            style = MaterialTheme.typography.labelSmall,
                            color = RacingAmber,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "HIGHWAY\nLEGENDS 3D",
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontSize = 34.sp,
                            lineHeight = 36.sp
                        ),
                        color = TextPrimary
                    )
                }

                // Distance Records Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TelemetryStatPill(
                        label = stringResource(R.string.label_best_distance),
                        value = formatDistance(progress.bestDistanceMeters),
                        accent = RacingAmber,
                        modifier = Modifier.weight(1f)
                    )
                    TelemetryStatPill(
                        label = stringResource(R.string.label_total_distance),
                        value = formatDistance(progress.totalDistanceMeters),
                        accent = RacingCyan,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Menu Buttons
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onStartRace,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RacingAmber,
                            contentColor = CarbonBlack
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("race_now_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.action_drive),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MenuSecondaryButton(
                            icon = Icons.Filled.DirectionsCar,
                            label = stringResource(R.string.action_garage),
                            onClick = onOpenGarage,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("garage_button")
                        )
                        MenuSecondaryButton(
                            icon = Icons.Filled.Landscape,
                            label = stringResource(R.string.action_environments),
                            onClick = onOpenEnvironments,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("environments_button")
                        )
                        MenuSecondaryButton(
                            icon = Icons.Filled.Settings,
                            label = stringResource(R.string.action_settings),
                            onClick = onOpenSettings,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("settings_button")
                        )
                    }
                }
            }

            // Right Corner: Live Showcase Car & Highway Status Pill
            Column(
                modifier = Modifier.fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.End
            ) {
                Surface(
                    color = CarbonSurface.copy(alpha = 0.84f),
                    border = BorderStroke(1.dp, CarbonBorder),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Speed,
                                contentDescription = null,
                                tint = RacingAmber,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = selectedCar.name.uppercase(),
                                style = MaterialTheme.typography.titleLarge,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = "${selectedCar.topSpeedKmh.toInt()} KM/H TOP • ${selectedEnv.title}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }

                // Modular AdMob Banner Hook (renders empty during offline dev mode)
                adProvider.BannerAdSlot(
                    placement = AdPlacement.MENU_BANNER,
                    modifier = Modifier
                )
            }
        }
    }
}

@Composable
private fun TelemetryStatPill(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = CarbonSurface.copy(alpha = 0.85f),
        border = BorderStroke(1.dp, CarbonBorder),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = accent
            )
        }
    }
}

@Composable
private fun MenuSecondaryButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, CarbonBorder),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = CarbonSurface.copy(alpha = 0.82f),
            contentColor = TextPrimary
        ),
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 10.dp),
        modifier = modifier.height(50.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = RacingAmber,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                maxLines = 1
            )
        }
    }
}
