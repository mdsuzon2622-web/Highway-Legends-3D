package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.EnvironmentCatalog
import com.example.model.EnvironmentId
import com.example.model.EnvironmentTheme
import com.example.model.PlayerProgress
import com.example.ui.theme.CarbonBlack
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonElevated
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.RacingAmber
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun EnvironmentsScreen(
    progress: PlayerProgress,
    onSelectEnvironment: (EnvironmentId) -> Unit,
    onStartRace: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeEnv = EnvironmentCatalog.byId(progress.selectedEnvironmentId)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        CarbonBlack.copy(alpha = 0.72f),
                        Color.Transparent,
                        CarbonBlack.copy(alpha = 0.88f)
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onBack,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = CarbonSurface.copy(alpha = 0.85f),
                            contentColor = TextPrimary
                        ),
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("environments_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.action_environments),
                            style = MaterialTheme.typography.headlineMedium,
                            color = TextPrimary
                        )
                        Text(
                            text = "${activeEnv.title} — ${activeEnv.subtitle}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = RacingAmber
                        )
                    }
                }

                Button(
                    onClick = onStartRace,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RacingAmber,
                        contentColor = CarbonBlack
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("environments_race_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.action_drive),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Bottom Horizontal Scrollable 7 Environments Strip
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(EnvironmentCatalog.all, key = { it.id.storageKey }) { env ->
                    val isSelected = env.id == activeEnv.id
                    val envBest = progress.bestDistanceByEnv[env.id] ?: 0f
                    EnvironmentCard(
                        env = env,
                        bestDistanceMeters = envBest,
                        isSelected = isSelected,
                        onClick = { onSelectEnvironment(env.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun EnvironmentCard(
    env: EnvironmentTheme,
    bestDistanceMeters: Float,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val accent = Color(env.previewAccentHex)
    Surface(
        onClick = onClick,
        color = if (isSelected) CarbonElevated.copy(alpha = 0.94f) else CarbonSurface.copy(alpha = 0.84f),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) RacingAmber else CarbonBorder
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .width(210.dp)
            .height(132.dp)
            .testTag("env_card_${env.id.storageKey}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = accent.copy(alpha = 0.22f),
                    border = BorderStroke(1.dp, accent),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Icon(
                        imageVector = if (env.isNight) Icons.Filled.NightsStay else Icons.Filled.WbSunny,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier
                            .padding(5.dp)
                            .size(16.dp)
                    )
                }

                if (isSelected) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = stringResource(R.string.action_selected),
                        tint = RacingAmber,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Column {
                Text(
                    text = env.title,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                    maxLines = 1
                )
                Text(
                    text = env.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    maxLines = 2
                )
            }

            Text(
                text = "BEST: ${formatDistance(bestDistanceMeters)}",
                style = MaterialTheme.typography.labelSmall,
                color = RacingAmber
            )
        }
    }
}
