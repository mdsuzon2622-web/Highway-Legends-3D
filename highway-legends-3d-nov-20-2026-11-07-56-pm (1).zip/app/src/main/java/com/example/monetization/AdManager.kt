package com.example.monetization

import android.app.Activity
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/**
 * Official Google AdMob Test Ad Unit IDs.
 * Swap with production IDs only when releasing with com.google.android.gms:play-services-ads
 * and a valid APPLICATION_ID meta-data entry in AndroidManifest.xml.
 */
object AdUnitConfig {
    const val TEST_BANNER_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
    const val TEST_INTERSTITIAL_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_REWARDED_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
}

enum class AdPlacement {
    MENU_BANNER,
    POST_RACE_INTERSTITIAL,
    OPTIONAL_REWARDED_RECOVERY
}

interface AdProvider {
    val isTestMode: Boolean
    val isSdkAvailable: Boolean

    fun initialize()
    fun loadInterstitial()
    fun showInterstitial(activity: Activity?, onDismissed: () -> Unit)
    fun loadRewarded()
    fun showRewarded(
        activity: Activity?,
        onRewardEarned: () -> Unit,
        onDismissed: () -> Unit
    )

    @Composable
    fun BannerAdSlot(placement: AdPlacement, modifier: Modifier)
}

/**
 * Offline-safe development implementation.
 * Displays zero real advertisements during development and preserves core offline playability
 * while keeping Banner, Interstitial, and Rewarded integration hooks cleanly wired.
 */
class OfflineTestAdProvider : AdProvider {
    override val isTestMode: Boolean = true
    override val isSdkAvailable: Boolean = false

    override fun initialize() {
        // Future AdMob MobileAds.initialize(context) hook
    }

    override fun loadInterstitial() {
        // Future InterstitialAd.load(...) hook using AdUnitConfig.TEST_INTERSTITIAL_UNIT_ID
    }

    override fun showInterstitial(activity: Activity?, onDismissed: () -> Unit) {
        // No real ads displayed during development; immediately proceed
        onDismissed()
    }

    override fun loadRewarded() {
        // Future RewardedAd.load(...) hook using AdUnitConfig.TEST_REWARDED_UNIT_ID
    }

    override fun showRewarded(
        activity: Activity?,
        onRewardEarned: () -> Unit,
        onDismissed: () -> Unit
    ) {
        onDismissed()
    }

    @Composable
    override fun BannerAdSlot(placement: AdPlacement, modifier: Modifier) {
        // Intentionally renders nothing during development when AdMob SDK is not attached
    }
}
