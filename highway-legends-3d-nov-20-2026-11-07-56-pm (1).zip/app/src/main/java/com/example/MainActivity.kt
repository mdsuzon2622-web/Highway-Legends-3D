package com.example

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.GameScreen
import com.example.render.HighwayGLSurfaceView
import com.example.ui.GameViewModel
import com.example.ui.screens.EnvironmentsScreen
import com.example.ui.screens.GameOverOverlay
import com.example.ui.screens.GarageScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.PausedOverlay
import com.example.ui.screens.RacingHudOverlay
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.HighwayLegendsTheme

class MainActivity : ComponentActivity() {
    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        configureImmersiveLandscape()

        setContent {
            HighwayLegendsTheme {
                HighwayLegendsRoot(viewModel = viewModel)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        viewModel.pauseRace()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            configureImmersiveLandscape()
        }
    }

    private fun configureImmersiveLandscape() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }
}

@Composable
fun HighwayLegendsRoot(viewModel: GameViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val activity = context as? Activity

    val isShowcase = when (state.screen) {
        GameScreen.MAIN_MENU,
        GameScreen.GARAGE,
        GameScreen.ENVIRONMENTS,
        GameScreen.SETTINGS -> true
        GameScreen.PLAYING,
        GameScreen.PAUSED,
        GameScreen.GAME_OVER -> false
    }

    BackHandler(enabled = state.screen != GameScreen.MAIN_MENU) {
        viewModel.handleBackPress()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Real-time OpenGL ES 3D World Background / Gameplay Canvas
        HighwayGLSurfaceView(
            physicsEngine = viewModel.physicsEngine,
            environmentId = state.progress.selectedEnvironmentId,
            isShowcaseMode = isShowcase,
            modifier = Modifier.fillMaxSize()
        )

        when (state.screen) {
            GameScreen.MAIN_MENU -> {
                MainMenuScreen(
                    progress = state.progress,
                    adProvider = viewModel.adProvider,
                    onStartRace = { viewModel.startRace() },
                    onOpenGarage = { viewModel.navigateTo(GameScreen.GARAGE) },
                    onOpenEnvironments = { viewModel.navigateTo(GameScreen.ENVIRONMENTS) },
                    onOpenSettings = { viewModel.navigateTo(GameScreen.SETTINGS) }
                )
            }

            GameScreen.PLAYING -> {
                RacingHudOverlay(
                    telemetry = state.telemetry,
                    environmentId = state.progress.selectedEnvironmentId,
                    steeringMode = state.soundSettings.steeringMode,
                    leftHeld = state.leftSteerHeld,
                    rightHeld = state.rightSteerHeld,
                    gasHeld = state.gasHeld,
                    brakeHeld = state.brakeHeld,
                    tiltSteerValue = state.tiltSteerValue,
                    onLeftHeldChange = { viewModel.setLeftSteerHeld(it) },
                    onRightHeldChange = { viewModel.setRightSteerHeld(it) },
                    onGasHeldChange = { viewModel.setGasHeld(it) },
                    onBrakeHeldChange = { viewModel.setBrakeHeld(it) },
                    onCycleCamera = { viewModel.cycleCameraMode() },
                    onPause = { viewModel.pauseRace() }
                )
            }

            GameScreen.PAUSED -> {
                PausedOverlay(
                    telemetry = state.telemetry,
                    soundSettings = state.soundSettings,
                    onResume = { viewModel.resumeRace() },
                    onRestart = { viewModel.restartRace() },
                    onCycleCamera = { viewModel.cycleCameraMode() },
                    onToggleSound = {
                        viewModel.updateSoundSettings { it.copy(soundEnabled = !it.soundEnabled) }
                    },
                    onMainMenu = { viewModel.navigateTo(GameScreen.MAIN_MENU) }
                )
            }

            GameScreen.GAME_OVER -> {
                GameOverOverlay(
                    telemetry = state.telemetry,
                    bestDistanceMeters = state.progress.bestDistanceMeters,
                    isNewRecord = state.isNewRecord,
                    onRestart = {
                        viewModel.showPostCrashInterstitialIfReady(activity) {
                            viewModel.restartRace()
                        }
                    },
                    onOpenGarage = { viewModel.navigateTo(GameScreen.GARAGE) },
                    onMainMenu = { viewModel.navigateTo(GameScreen.MAIN_MENU) }
                )
            }

            GameScreen.GARAGE -> {
                GarageScreen(
                    progress = state.progress,
                    onSelectCar = { carId, paintIdx -> viewModel.selectCar(carId, paintIdx) },
                    onStartRace = { viewModel.startRace() },
                    onBack = { viewModel.navigateTo(GameScreen.MAIN_MENU) }
                )
            }

            GameScreen.ENVIRONMENTS -> {
                EnvironmentsScreen(
                    progress = state.progress,
                    onSelectEnvironment = { viewModel.selectEnvironment(it) },
                    onStartRace = { viewModel.startRace() },
                    onBack = { viewModel.navigateTo(GameScreen.MAIN_MENU) }
                )
            }

            GameScreen.SETTINGS -> {
                SettingsScreen(
                    soundSettings = state.soundSettings,
                    onUpdateSettings = { viewModel.updateSoundSettings(it) },
                    onBack = { viewModel.navigateTo(GameScreen.MAIN_MENU) }
                )
            }
        }
    }
}
