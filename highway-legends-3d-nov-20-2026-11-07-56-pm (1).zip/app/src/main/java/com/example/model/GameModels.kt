package com.example.model

enum class EnvironmentId(val storageKey: String) {
    COUNTRYSIDE("countryside"),
    MODERN_CITY("modern_city"),
    DENSE_FOREST("dense_forest"),
    MOUNTAIN_HIGHWAY("mountain_highway"),
    COASTAL_ROAD("coastal_road"),
    DESERT_HIGHWAY("desert_highway"),
    NIGHTTIME_ROAD("nighttime_road");

    companion object {
        fun fromKey(key: String?): EnvironmentId =
            entries.firstOrNull { it.storageKey == key } ?: COUNTRYSIDE
    }
}

data class EnvironmentTheme(
    val id: EnvironmentId,
    val title: String,
    val subtitle: String,
    val skyTopRgb: FloatArray,
    val skyHorizonRgb: FloatArray,
    val fogRgb: FloatArray,
    val groundLeftRgb: FloatArray,
    val groundRightRgb: FloatArray,
    val roadRgb: FloatArray,
    val shoulderRgb: FloatArray,
    val laneLineRgb: FloatArray,
    val propPrimaryRgb: FloatArray,
    val propSecondaryRgb: FloatArray,
    val ambientStrength: Float,
    val sunStrength: Float,
    val isNight: Boolean = false,
    val hasOceanRight: Boolean = false,
    val previewAccentHex: Long
)

object EnvironmentCatalog {
    val all: List<EnvironmentTheme> = listOf(
        EnvironmentTheme(
            id = EnvironmentId.COUNTRYSIDE,
            title = "Green Countryside",
            subtitle = "Sunlit rolling meadows & timber barns",
            skyTopRgb = floatArrayOf(0.18f, 0.52f, 0.89f),
            skyHorizonRgb = floatArrayOf(0.72f, 0.88f, 0.98f),
            fogRgb = floatArrayOf(0.72f, 0.87f, 0.96f),
            groundLeftRgb = floatArrayOf(0.22f, 0.54f, 0.21f),
            groundRightRgb = floatArrayOf(0.25f, 0.57f, 0.23f),
            roadRgb = floatArrayOf(0.16f, 0.17f, 0.19f),
            shoulderRgb = floatArrayOf(0.45f, 0.44f, 0.41f),
            laneLineRgb = floatArrayOf(0.95f, 0.95f, 0.92f),
            propPrimaryRgb = floatArrayOf(0.14f, 0.42f, 0.16f),
            propSecondaryRgb = floatArrayOf(0.68f, 0.20f, 0.16f),
            ambientStrength = 0.52f,
            sunStrength = 0.85f,
            previewAccentHex = 0xFF38A169
        ),
        EnvironmentTheme(
            id = EnvironmentId.MODERN_CITY,
            title = "Modern Cities",
            subtitle = "Glass skyscrapers & metropolitan expressway",
            skyTopRgb = floatArrayOf(0.15f, 0.30f, 0.52f),
            skyHorizonRgb = floatArrayOf(0.68f, 0.76f, 0.86f),
            fogRgb = floatArrayOf(0.64f, 0.72f, 0.82f),
            groundLeftRgb = floatArrayOf(0.22f, 0.24f, 0.28f),
            groundRightRgb = floatArrayOf(0.22f, 0.24f, 0.28f),
            roadRgb = floatArrayOf(0.13f, 0.14f, 0.16f),
            shoulderRgb = floatArrayOf(0.36f, 0.38f, 0.42f),
            laneLineRgb = floatArrayOf(0.96f, 0.96f, 0.98f),
            propPrimaryRgb = floatArrayOf(0.28f, 0.42f, 0.58f),
            propSecondaryRgb = floatArrayOf(0.85f, 0.88f, 0.96f),
            ambientStrength = 0.48f,
            sunStrength = 0.78f,
            previewAccentHex = 0xFF3B82F6
        ),
        EnvironmentTheme(
            id = EnvironmentId.DENSE_FOREST,
            title = "Dense Forests",
            subtitle = "Towering evergreens & misty woodland curves",
            skyTopRgb = floatArrayOf(0.14f, 0.34f, 0.40f),
            skyHorizonRgb = floatArrayOf(0.56f, 0.73f, 0.68f),
            fogRgb = floatArrayOf(0.52f, 0.68f, 0.64f),
            groundLeftRgb = floatArrayOf(0.11f, 0.29f, 0.14f),
            groundRightRgb = floatArrayOf(0.12f, 0.31f, 0.15f),
            roadRgb = floatArrayOf(0.15f, 0.16f, 0.17f),
            shoulderRgb = floatArrayOf(0.34f, 0.32f, 0.28f),
            laneLineRgb = floatArrayOf(0.95f, 0.88f, 0.48f),
            propPrimaryRgb = floatArrayOf(0.08f, 0.26f, 0.12f),
            propSecondaryRgb = floatArrayOf(0.32f, 0.20f, 0.12f),
            ambientStrength = 0.44f,
            sunStrength = 0.68f,
            previewAccentHex = 0xFF15803D
        ),
        EnvironmentTheme(
            id = EnvironmentId.MOUNTAIN_HIGHWAY,
            title = "Mountain Highways",
            subtitle = "Alpine granite cliffs & snow-capped ridges",
            skyTopRgb = floatArrayOf(0.12f, 0.40f, 0.76f),
            skyHorizonRgb = floatArrayOf(0.76f, 0.86f, 0.96f),
            fogRgb = floatArrayOf(0.74f, 0.83f, 0.93f),
            groundLeftRgb = floatArrayOf(0.35f, 0.37f, 0.41f),
            groundRightRgb = floatArrayOf(0.33f, 0.36f, 0.40f),
            roadRgb = floatArrayOf(0.16f, 0.17f, 0.19f),
            shoulderRgb = floatArrayOf(0.50f, 0.51f, 0.54f),
            laneLineRgb = floatArrayOf(0.96f, 0.96f, 0.96f),
            propPrimaryRgb = floatArrayOf(0.40f, 0.42f, 0.46f),
            propSecondaryRgb = floatArrayOf(0.93f, 0.95f, 0.98f),
            ambientStrength = 0.50f,
            sunStrength = 0.86f,
            previewAccentHex = 0xFF64748B
        ),
        EnvironmentTheme(
            id = EnvironmentId.COASTAL_ROAD,
            title = "Coastal Roads",
            subtitle = "Turquoise ocean surf & sunlit palm cliffs",
            skyTopRgb = floatArrayOf(0.10f, 0.55f, 0.88f),
            skyHorizonRgb = floatArrayOf(0.74f, 0.92f, 0.98f),
            fogRgb = floatArrayOf(0.72f, 0.90f, 0.96f),
            groundLeftRgb = floatArrayOf(0.78f, 0.70f, 0.48f),
            groundRightRgb = floatArrayOf(0.06f, 0.48f, 0.72f),
            roadRgb = floatArrayOf(0.18f, 0.19f, 0.21f),
            shoulderRgb = floatArrayOf(0.68f, 0.64f, 0.52f),
            laneLineRgb = floatArrayOf(0.98f, 0.98f, 0.95f),
            propPrimaryRgb = floatArrayOf(0.18f, 0.54f, 0.22f),
            propSecondaryRgb = floatArrayOf(0.56f, 0.42f, 0.26f),
            ambientStrength = 0.56f,
            sunStrength = 0.88f,
            hasOceanRight = true,
            previewAccentHex = 0xFF06B6D4
        ),
        EnvironmentTheme(
            id = EnvironmentId.DESERT_HIGHWAY,
            title = "Desert Highways",
            subtitle = "Red canyon mesas, golden dunes & heat haze",
            skyTopRgb = floatArrayOf(0.24f, 0.50f, 0.82f),
            skyHorizonRgb = floatArrayOf(0.95f, 0.78f, 0.54f),
            fogRgb = floatArrayOf(0.92f, 0.76f, 0.54f),
            groundLeftRgb = floatArrayOf(0.80f, 0.58f, 0.34f),
            groundRightRgb = floatArrayOf(0.78f, 0.56f, 0.32f),
            roadRgb = floatArrayOf(0.18f, 0.17f, 0.17f),
            shoulderRgb = floatArrayOf(0.66f, 0.50f, 0.33f),
            laneLineRgb = floatArrayOf(0.96f, 0.82f, 0.28f),
            propPrimaryRgb = floatArrayOf(0.68f, 0.33f, 0.20f),
            propSecondaryRgb = floatArrayOf(0.22f, 0.50f, 0.22f),
            ambientStrength = 0.54f,
            sunStrength = 0.90f,
            previewAccentHex = 0xFFD97706
        ),
        EnvironmentTheme(
            id = EnvironmentId.NIGHTTIME_ROAD,
            title = "Nighttime Roads",
            subtitle = "Starry midnight asphalt, streetlamps & high beams",
            skyTopRgb = floatArrayOf(0.02f, 0.03f, 0.09f),
            skyHorizonRgb = floatArrayOf(0.08f, 0.12f, 0.26f),
            fogRgb = floatArrayOf(0.04f, 0.06f, 0.14f),
            groundLeftRgb = floatArrayOf(0.05f, 0.06f, 0.10f),
            groundRightRgb = floatArrayOf(0.05f, 0.06f, 0.10f),
            roadRgb = floatArrayOf(0.07f, 0.08f, 0.11f),
            shoulderRgb = floatArrayOf(0.14f, 0.16f, 0.22f),
            laneLineRgb = floatArrayOf(0.92f, 0.94f, 0.98f),
            propPrimaryRgb = floatArrayOf(0.10f, 0.13f, 0.24f),
            propSecondaryRgb = floatArrayOf(1.00f, 0.76f, 0.24f),
            ambientStrength = 0.25f,
            sunStrength = 0.36f,
            isNight = true,
            previewAccentHex = 0xFF6366F1
        )
    )

    fun byId(id: EnvironmentId): EnvironmentTheme =
        all.firstOrNull { it.id == id } ?: all.first()
}

data class CarPaintOption(
    val name: String,
    val bodyRgb: FloatArray,
    val accentRgb: FloatArray,
    val previewHex: Long
)

data class CarSpec(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val topSpeedKmh: Float,
    val accelerationRate: Float,
    val handlingSpeed: Float,
    val brakingPower: Float,
    val hasRearWing: Boolean,
    val hasRoofScoop: Boolean,
    val width: Float = 1.92f,
    val length: Float = 4.35f,
    val height: Float = 1.22f,
    val paintOptions: List<CarPaintOption>
)

object CarCatalog {
    val all: List<CarSpec> = listOf(
        CarSpec(
            id = "apex_gt",
            name = "Apex GT",
            category = "SPORT COUPE",
            description = "Balanced mid-engine grand tourer with crisp cornering grip.",
            topSpeedKmh = 265f,
            accelerationRate = 24f,
            handlingSpeed = 7.4f,
            brakingPower = 54f,
            hasRearWing = false,
            hasRoofScoop = false,
            paintOptions = listOf(
                CarPaintOption("Crimson Red", floatArrayOf(0.86f, 0.12f, 0.18f), floatArrayOf(0.98f, 0.76f, 0.12f), 0xFFDC1F2E),
                CarPaintOption("Cobalt Blue", floatArrayOf(0.10f, 0.38f, 0.90f), floatArrayOf(0.92f, 0.95f, 1.0f), 0xFF1A61E6),
                CarPaintOption("Pearl White", floatArrayOf(0.92f, 0.94f, 0.97f), floatArrayOf(0.90f, 0.18f, 0.22f), 0xFFEBF0F7)
            )
        ),
        CarSpec(
            id = "valkyrie_v8",
            name = "Valkyrie V8",
            category = "TRACK SUPERCAR",
            description = "Twin-turbo V8 track weapon built for high-speed lane weaving.",
            topSpeedKmh = 295f,
            accelerationRate = 28f,
            handlingSpeed = 8.2f,
            brakingPower = 60f,
            hasRearWing = true,
            hasRoofScoop = false,
            paintOptions = listOf(
                CarPaintOption("Solar Amber", floatArrayOf(0.96f, 0.58f, 0.06f), floatArrayOf(0.12f, 0.14f, 0.18f), 0xFFF5940F),
                CarPaintOption("Emerald Green", floatArrayOf(0.08f, 0.62f, 0.36f), floatArrayOf(0.94f, 0.85f, 0.20f), 0xFF149E5C),
                CarPaintOption("Stealth Matte", floatArrayOf(0.16f, 0.18f, 0.22f), floatArrayOf(0.0f, 0.88f, 1.0f), 0xFF292E38)
            )
        ),
        CarSpec(
            id = "solaris_hyper",
            name = "Solaris Hyper",
            category = "HYPERCAR",
            description = "Aerodynamic carbon hypercar engineered for extreme highway velocity.",
            topSpeedKmh = 335f,
            accelerationRate = 32f,
            handlingSpeed = 8.8f,
            brakingPower = 66f,
            hasRearWing = true,
            hasRoofScoop = true,
            width = 1.98f,
            length = 4.48f,
            height = 1.14f,
            paintOptions = listOf(
                CarPaintOption("Electric Cyan", floatArrayOf(0.04f, 0.72f, 0.92f), floatArrayOf(0.96f, 0.98f, 1.0f), 0xFF0AB8EB),
                CarPaintOption("Obsidian Gold", floatArrayOf(0.12f, 0.12f, 0.15f), floatArrayOf(0.98f, 0.74f, 0.14f), 0xFF1F1F26),
                CarPaintOption("Inferno Orange", floatArrayOf(0.94f, 0.30f, 0.08f), floatArrayOf(0.14f, 0.14f, 0.16f), 0xFFF04D14)
            )
        ),
        CarSpec(
            id = "phantom_rs",
            name = "Phantom RS",
            category = "MUSCLE GT",
            description = "Heavy-torque V10 coupe with ferocious acceleration and stability.",
            topSpeedKmh = 280f,
            accelerationRate = 30f,
            handlingSpeed = 7.2f,
            brakingPower = 56f,
            hasRearWing = false,
            hasRoofScoop = true,
            width = 1.96f,
            length = 4.42f,
            height = 1.26f,
            paintOptions = listOf(
                CarPaintOption("Violet Pulse", floatArrayOf(0.46f, 0.22f, 0.86f), floatArrayOf(0.95f, 0.95f, 0.98f), 0xFF7538DB),
                CarPaintOption("Titanium Silver", floatArrayOf(0.68f, 0.72f, 0.78f), floatArrayOf(0.86f, 0.16f, 0.22f), 0xFFADB8C7),
                CarPaintOption("Midnight Navy", floatArrayOf(0.10f, 0.20f, 0.48f), floatArrayOf(0.98f, 0.76f, 0.14f), 0xFF1A337A)
            )
        ),
        CarSpec(
            id = "titan_interceptor",
            name = "Titan Spec-R",
            category = "ENDURANCE PRO",
            description = "Track-homologated GT endurance racer with razor-sharp aero downforce.",
            topSpeedKmh = 315f,
            accelerationRate = 29f,
            handlingSpeed = 9.2f,
            brakingPower = 68f,
            hasRearWing = true,
            hasRoofScoop = true,
            paintOptions = listOf(
                CarPaintOption("Lime Corsa", floatArrayOf(0.48f, 0.84f, 0.12f), floatArrayOf(0.12f, 0.14f, 0.16f), 0xFF7AD61F),
                CarPaintOption("Ruby Metallic", floatArrayOf(0.72f, 0.08f, 0.24f), floatArrayOf(0.96f, 0.96f, 0.98f), 0xFFB8143D),
                CarPaintOption("Arctic Ice", floatArrayOf(0.86f, 0.92f, 0.98f), floatArrayOf(0.04f, 0.66f, 0.94f), 0xFFDBEBF9)
            )
        )
    )

    fun byId(id: String?): CarSpec =
        all.firstOrNull { it.id == id } ?: all.first()
}

enum class CameraMode(val label: String) {
    CHASE_NEAR("CHASE"),
    CHASE_FAR("FAR CHASE"),
    HOOD("HOOD"),
    BUMPER("BUMPER");

    fun next(): CameraMode {
        val list = entries
        return list[(ordinal + 1) % list.size]
    }
}

enum class SteeringMode(val storageKey: String) {
    TOUCH("touch"),
    TILT("tilt");

    companion object {
        fun fromKey(key: String?): SteeringMode =
            entries.firstOrNull { it.storageKey == key } ?: TOUCH
    }
}

enum class TrafficVehicleType(
    val width: Float,
    val length: Float,
    val height: Float
) {
    SEDAN(1.86f, 4.30f, 1.38f),
    SUV(1.98f, 4.65f, 1.68f),
    SPORTS_TRAFFIC(1.90f, 4.25f, 1.22f),
    PICKUP(2.00f, 4.85f, 1.72f),
    BOX_TRUCK(2.26f, 7.10f, 2.85f)
}

data class TrafficVehicle(
    val id: Int,
    val lane: Int,
    val x: Float,
    val z: Float,
    val speedKmh: Float,
    val type: TrafficVehicleType,
    val colorRgb: FloatArray
)

enum class GameScreen {
    MAIN_MENU,
    PLAYING,
    PAUSED,
    GAME_OVER,
    GARAGE,
    ENVIRONMENTS,
    SETTINGS
}

data class SoundSettings(
    val soundEnabled: Boolean = true,
    val engineVolume: Float = 0.75f,
    val sfxVolume: Float = 0.85f,
    val steeringMode: SteeringMode = SteeringMode.TOUCH
)

data class PlayerProgress(
    val selectedCarId: String = CarCatalog.all.first().id,
    val selectedPaintIndex: Int = 0,
    val selectedEnvironmentId: EnvironmentId = EnvironmentId.COUNTRYSIDE,
    val bestDistanceMeters: Float = 0f,
    val totalDistanceMeters: Float = 0f,
    val bestDistanceByEnv: Map<EnvironmentId, Float> = emptyMap(),
    val racesCompleted: Int = 0
)
