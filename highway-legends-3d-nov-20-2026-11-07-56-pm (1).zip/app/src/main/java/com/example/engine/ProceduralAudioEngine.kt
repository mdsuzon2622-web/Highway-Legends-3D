package com.example.engine

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.model.SoundSettings
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

class ProceduralAudioEngine {
    private val sampleRate = 22050
    private val bufferSamples = 1024

    @Volatile
    private var isRunning = false

    @Volatile
    private var isRacing = false

    @Volatile
    private var rpmNormalized = 0.25f

    @Volatile
    private var isBraking = false

    @Volatile
    private var settings = SoundSettings()

    @Volatile
    private var crashImpulse = 0f

    @Volatile
    private var nearMissImpulse = 0f

    private var audioThread: Thread? = null
    private var audioTrack: AudioTrack? = null

    fun updateSettings(newSettings: SoundSettings) {
        settings = newSettings
    }

    fun updateTelemetry(rpm: Float, braking: Boolean, racing: Boolean) {
        rpmNormalized = rpm.coerceIn(0.15f, 1.0f)
        isBraking = braking
        isRacing = racing
    }

    fun triggerCrash() {
        crashImpulse = 1.0f
    }

    fun triggerNearMiss() {
        nearMissImpulse = 0.8f
    }

    fun start() {
        if (isRunning) return
        isRunning = true
        audioThread = thread(start = true, isDaemon = true, name = "HighwayAudioSynth") {
            val minBufBytes = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (minBufBytes <= 0) {
                isRunning = false
                return@thread
            }

            val track = try {
                AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(maxOf(minBufBytes, bufferSamples * 4))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
            } catch (_: Throwable) {
                isRunning = false
                return@thread
            }

            audioTrack = track
            try {
                track.play()
            } catch (_: Throwable) {
                releaseInternal()
                return@thread
            }

            val pcm = ShortArray(bufferSamples)
            var phase1 = 0.0
            var phase2 = 0.0
            var phaseSub = 0.0
            var smoothedFreq = 65.0
            val twoPi = 2.0 * PI
            val rng = Random(42)

            while (isRunning) {
                val cfg = settings
                if (!cfg.soundEnabled || (!isRacing && crashImpulse <= 0.01f && nearMissImpulse <= 0.01f)) {
                    pcm.fill(0)
                    try {
                        track.write(pcm, 0, pcm.size)
                    } catch (_: Throwable) {
                        break
                    }
                    continue
                }

                val targetFreq = if (isRacing) {
                    52.0 + rpmNormalized * 148.0
                } else {
                    48.0
                }
                val engVol = if (isRacing) cfg.engineVolume.toDouble() else 0.0
                val sfxVol = cfg.sfxVolume.toDouble()

                for (i in pcm.indices) {
                    smoothedFreq += (targetFreq - smoothedFreq) * 0.008
                    phase1 += twoPi * smoothedFreq / sampleRate
                    phase2 += twoPi * (smoothedFreq * 2.01) / sampleRate
                    phaseSub += twoPi * (smoothedFreq * 0.5) / sampleRate
                    if (phase1 > twoPi) phase1 -= twoPi
                    if (phase2 > twoPi) phase2 -= twoPi
                    if (phaseSub > twoPi) phaseSub -= twoPi

                    // Warm multi-harmonic sports car engine growl
                    val engineSample = (
                        sin(phase1) * 0.45 +
                            sin(phase2) * 0.30 +
                            sin(phaseSub) * 0.35 +
                            sin(phase1 * 3.0) * 0.14
                        ) * 0.22 * engVol

                    var sfxSample = 0.0
                    if (isRacing && isBraking) {
                        sfxSample += (rng.nextDouble() * 2.0 - 1.0) * 0.10 * sfxVol
                    }
                    if (crashImpulse > 0.002f) {
                        val noise = rng.nextDouble() * 2.0 - 1.0
                        sfxSample += (noise * 0.65 + sin(phaseSub) * 0.35) * crashImpulse * 0.55 * sfxVol
                        crashImpulse *= 0.9993f
                    }
                    if (nearMissImpulse > 0.002f) {
                        sfxSample += sin(phase2 * 2.4) * nearMissImpulse * 0.22 * sfxVol
                        nearMissImpulse *= 0.9990f
                    }

                    val mixed = (engineSample + sfxSample).coerceIn(-0.95, 0.95)
                    pcm[i] = (mixed * Short.MAX_VALUE).toInt().toShort()
                }

                try {
                    track.write(pcm, 0, pcm.size)
                } catch (_: Throwable) {
                    break
                }
            }

            releaseInternal()
        }
    }

    fun stop() {
        isRunning = false
        audioThread?.interrupt()
        audioThread = null
    }

    private fun releaseInternal() {
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.release()
        } catch (_: Throwable) {
        }
        audioTrack = null
    }
}
