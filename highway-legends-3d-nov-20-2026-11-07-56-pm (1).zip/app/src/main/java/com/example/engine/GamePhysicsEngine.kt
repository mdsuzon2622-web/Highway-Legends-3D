package com.example.engine

import com.example.model.CameraMode
import com.example.model.CarCatalog
import com.example.model.CarSpec
import com.example.model.TrafficVehicle
import com.example.model.TrafficVehicleType
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

object HighwayTrackMath {
    const val LANE_COUNT = 4
    const val LANE_WIDTH = 3.6f
    const val ROAD_WIDTH = LANE_COUNT * LANE_WIDTH // 14.4m
    const val SHOULDER_WIDTH = 1.6f
    const val MAX_PLAYER_X = (ROAD_WIDTH * 0.5f) - 1.15f // 6.05m

    val LANE_CENTERS: FloatArray = floatArrayOf(
        -1.5f * LANE_WIDTH, // -5.4f
        -0.5f * LANE_WIDTH, // -1.8f
        0.5f * LANE_WIDTH,  // +1.8f
        1.5f * LANE_WIDTH   // +5.4f
    )

    fun roadCurveX(z: Float): Float {
        return sin(z * 0.0045f) * 14.0f + sin(z * 0.0019f + 1.1f) * 9.0f
    }

    fun roadCurveSlopeX(z: Float): Float {
        return cos(z * 0.0045f) * 14.0f * 0.0045f +
            cos(z * 0.0019f + 1.1f) * 9.0f * 0.0019f
    }

    fun roadHillY(z: Float): Float {
        return sin(z * 0.0055f) * 2.8f + cos(z * 0.0023f) * 1.6f
    }
}

data class RenderSnapshot(
    val playerX: Float,
    val playerZ: Float,
    val speedKmh: Float,
    val steerVisualAngleDeg: Float,
    val bodyRollDeg: Float,
    val wheelSpinRad: Float,
    val isBraking: Boolean,
    val hasCrashed: Boolean,
    val cameraShake: Float,
    val cameraMode: CameraMode,
    val traffic: List<TrafficVehicle>,
    val carSpec: CarSpec,
    val paintIndex: Int,
    val showcaseAngleRad: Float
)

data class HudTelemetry(
    val speedKmh: Int = 0,
    val distanceMeters: Float = 0f,
    val gear: Int = 1,
    val rpmNormalized: Float = 0.2f,
    val nearMissCount: Int = 0,
    val topSpeedReachedKmh: Int = 0,
    val cameraMode: CameraMode = CameraMode.CHASE_NEAR,
    val hasCrashed: Boolean = false,
    val showNearMissBanner: Boolean = false
)

class GamePhysicsEngine(
    private val random: Random = Random.Default
) {
    private var carSpec: CarSpec = CarCatalog.all.first()
    private var paintIndex: Int = 0

    var playerX: Float = HighwayTrackMath.LANE_CENTERS[1]
        private set
    var playerZ: Float = 0f
        private set
    var speedKmh: Float = 75f
        private set
    var steerInput: Float = 0f
        private set
    var throttleInput: Float = 0f
        private set
    var brakeInput: Float = 0f
        private set
    var cameraMode: CameraMode = CameraMode.CHASE_NEAR
        private set

    var hasCrashed: Boolean = false
        private set
    var nearMissCount: Int = 0
        private set
    var topSpeedReachedKmh: Float = 0f
        private set

    private var steerVisualAngleDeg: Float = 0f
    private var bodyRollDeg: Float = 0f
    private var wheelSpinRad: Float = 0f
    private var cameraShake: Float = 0f
    private var nearMissBannerTimer: Float = 0f
    private var showcaseAngleRad: Float = 0.55f

    private val trafficList = mutableListOf<TrafficVehicle>()
    private val nearMissedIds = HashSet<Int>()
    private var nextTrafficId = 1
    private var nextSpawnZ = 65f

    private val trafficColors: List<FloatArray> = listOf(
        floatArrayOf(0.84f, 0.86f, 0.90f), // Silver
        floatArrayOf(0.18f, 0.22f, 0.28f), // Slate
        floatArrayOf(0.14f, 0.34f, 0.68f), // Navy blue
        floatArrayOf(0.76f, 0.18f, 0.20f), // Burgundy
        floatArrayOf(0.88f, 0.68f, 0.14f), // Taxi amber
        floatArrayOf(0.16f, 0.48f, 0.32f), // Forest green
        floatArrayOf(0.92f, 0.92f, 0.94f)  // White
    )

    @Synchronized
    fun configureCar(spec: CarSpec, selectedPaintIndex: Int) {
        carSpec = spec
        paintIndex = selectedPaintIndex.coerceIn(0, spec.paintOptions.lastIndex)
    }

    @Synchronized
    fun startNewRace(spec: CarSpec, selectedPaintIndex: Int) {
        configureCar(spec, selectedPaintIndex)
        playerX = HighwayTrackMath.LANE_CENTERS[1]
        playerZ = 0f
        speedKmh = 75f
        steerInput = 0f
        throttleInput = 0f
        brakeInput = 0f
        steerVisualAngleDeg = 0f
        bodyRollDeg = 0f
        wheelSpinRad = 0f
        hasCrashed = false
        cameraShake = 0f
        nearMissCount = 0
        nearMissBannerTimer = 0f
        topSpeedReachedKmh = speedKmh
        trafficList.clear()
        nearMissedIds.clear()
        nextTrafficId = 1
        nextSpawnZ = 75f

        while (nextSpawnZ < 320f) {
            spawnTrafficWave(nextSpawnZ)
            nextSpawnZ += random.nextFloat() * 24f + 32f
        }
    }

    @Synchronized
    fun setControls(steer: Float, throttle: Float, brake: Float) {
        steerInput = steer.coerceIn(-1f, 1f)
        throttleInput = throttle.coerceIn(0f, 1f)
        brakeInput = brake.coerceIn(0f, 1f)
    }

    @Synchronized
    fun cycleCameraMode(): CameraMode {
        cameraMode = cameraMode.next()
        return cameraMode
    }

    @Synchronized
    fun setCameraMode(mode: CameraMode) {
        cameraMode = mode
    }

    @Synchronized
    fun stepShowcase(deltaSec: Float) {
        val dt = deltaSec.coerceIn(0f, 0.05f)
        showcaseAngleRad = (showcaseAngleRad + dt * 0.42f) % (Math.PI.toFloat() * 2f)
        playerZ += 22f * dt
        wheelSpinRad += 18f * dt
    }

    @Synchronized
    fun stepRace(deltaSec: Float): Boolean {
        val dt = deltaSec.coerceIn(0.001f, 0.05f)
        if (nearMissBannerTimer > 0f) {
            nearMissBannerTimer = max(0f, nearMissBannerTimer - dt)
        }
        if (cameraShake > 0f) {
            cameraShake = max(0f, cameraShake - dt * 2.4f)
        }

        if (hasCrashed) {
            // Let traffic continue moving smoothly after crash
            advanceTraffic(dt)
            speedKmh = max(0f, speedKmh - 95f * dt)
            return false
        }

        // 1. Longitudinal speed update
        val drag = 0.00055f * speedKmh * speedKmh
        val rollingResistance = 3.2f
        val accel = if (throttleInput > 0f) {
            // Strong low-end torque tapering nicely toward top speed
            val speedRatio = (speedKmh / carSpec.topSpeedKmh).coerceIn(0f, 1f)
            carSpec.accelerationRate * throttleInput * (1.25f - 0.55f * speedRatio)
        } else {
            0f
        }
        val decel = brakeInput * carSpec.brakingPower + drag + rollingResistance
        speedKmh = (speedKmh + (accel - decel) * dt).coerceIn(0f, carSpec.topSpeedKmh)
        if (speedKmh > topSpeedReachedKmh) {
            topSpeedReachedKmh = speedKmh
        }

        val speedMps = speedKmh / 3.6f
        playerZ += speedMps * dt
        wheelSpinRad += (speedMps / 0.34f) * dt

        // 2. Lateral steering update (responsive, scaled smoothly with forward speed)
        val steerAuthority = (0.35f + 0.65f * min(1f, speedKmh / 65f))
        val targetLateralVel = steerInput * carSpec.handlingSpeed * steerAuthority
        playerX = (playerX + targetLateralVel * dt).coerceIn(
            -HighwayTrackMath.MAX_PLAYER_X,
            HighwayTrackMath.MAX_PLAYER_X
        )

        // Smooth visual yaw & body roll
        val targetYaw = steerInput * 11.5f * steerAuthority
        steerVisualAngleDeg += (targetYaw - steerVisualAngleDeg) * min(1f, dt * 12f)
        val targetRoll = -steerInput * 4.5f * steerAuthority
        bodyRollDeg += (targetRoll - bodyRollDeg) * min(1f, dt * 10f)

        // 3. Advance & recycle traffic
        advanceTraffic(dt)
        while (nextSpawnZ < playerZ + 330f) {
            spawnTrafficWave(nextSpawnZ)
            nextSpawnZ += random.nextFloat() * 24f + 30f
        }
        trafficList.removeAll { it.z < playerZ - 35f }

        // 4. Collision & Near-Miss detection
        val crashedNow = checkCollisionsAndNearMisses()
        if (crashedNow) {
            hasCrashed = true
            cameraShake = 1.0f
            return true
        }
        return false
    }

    private fun advanceTraffic(dt: Float) {
        for (i in trafficList.indices) {
            val v = trafficList[i]
            val dz = (v.speedKmh / 3.6f) * dt
            trafficList[i] = v.copy(z = v.z + dz)
        }
        // Prevent faster traffic cars in the same lane from overlapping slower cars ahead
        val byLane = trafficList.groupBy { it.lane }
        for ((_, carsInLane) in byLane) {
            val sorted = carsInLane.sortedBy { it.z }
            for (idx in 0 until sorted.size - 1) {
                val back = sorted[idx]
                val front = sorted[idx + 1]
                val minGap = (back.type.length + front.type.length) * 0.5f + 5.5f
                if (front.z - back.z < minGap && back.speedKmh > front.speedKmh) {
                    val backIdx = trafficList.indexOfFirst { it.id == back.id }
                    if (backIdx >= 0) {
                        trafficList[backIdx] = back.copy(
                            speedKmh = front.speedKmh,
                            z = min(back.z, front.z - minGap)
                        )
                    }
                }
            }
        }
    }

    private fun spawnTrafficWave(zPos: Float) {
        // Pick 1 to 2 lanes (never block all 4 lanes at the same Z)
        val count = if (random.nextFloat() < 0.45f) 2 else 1
        val lanes = (0 until HighwayTrackMath.LANE_COUNT).shuffled(random).take(count)
        for (lane in lanes) {
            val laneX = HighwayTrackMath.LANE_CENTERS[lane]
            // Avoid spawning right on top of an existing car in that lane
            val tooClose = trafficList.any { it.lane == lane && abs(it.z - zPos) < 28f }
            if (tooClose) continue

            val roll = random.nextFloat()
            val type = when {
                roll < 0.36f -> TrafficVehicleType.SEDAN
                roll < 0.58f -> TrafficVehicleType.SUV
                roll < 0.76f -> TrafficVehicleType.SPORTS_TRAFFIC
                roll < 0.90f -> TrafficVehicleType.PICKUP
                else -> TrafficVehicleType.BOX_TRUCK
            }
            val baseLaneSpeed = when (lane) {
                0 -> 68f
                1 -> 84f
                2 -> 98f
                else -> 114f
            }
            val speedVariance = random.nextFloat() * 14f - 7f
            val finalSpeed = if (type == TrafficVehicleType.BOX_TRUCK) {
                min(baseLaneSpeed, 78f)
            } else {
                baseLaneSpeed + speedVariance
            }

            trafficList.add(
                TrafficVehicle(
                    id = nextTrafficId++,
                    lane = lane,
                    x = laneX,
                    z = zPos + random.nextFloat() * 8f,
                    speedKmh = finalSpeed,
                    type = type,
                    colorRgb = trafficColors[random.nextInt(trafficColors.size)]
                )
            )
        }
    }

    private fun checkCollisionsAndNearMisses(): Boolean {
        val playerHalfW = carSpec.width * 0.44f
        val playerHalfL = carSpec.length * 0.45f

        for (v in trafficList) {
            val dx = abs(playerX - v.x)
            val dz = abs(playerZ - v.z)
            val hitHalfW = playerHalfW + v.type.width * 0.44f
            val hitHalfL = playerHalfL + v.type.length * 0.45f

            if (dx < hitHalfW && dz < hitHalfL) {
                return true
            }

            // Near-miss bonus check when passing close at high speed
            if (!nearMissedIds.contains(v.id) &&
                speedKmh >= 100f &&
                dz < hitHalfL + 1.2f &&
                dx < hitHalfW + 0.95f
            ) {
                nearMissedIds.add(v.id)
                nearMissCount += 1
                nearMissBannerTimer = 1.15f
            }
        }
        return false
    }

    @Synchronized
    fun computeGearAndRpm(): Pair<Int, Float> {
        val ratio = (speedKmh / carSpec.topSpeedKmh).coerceIn(0f, 1f)
        val gear = (1 + (ratio * 5.4f).toInt()).coerceIn(1, 6)
        val gearSpan = 1f / 6f
        val inGear = ((ratio - (gear - 1) * gearSpan) / gearSpan).coerceIn(0f, 1f)
        val rpm = (0.28f + inGear * 0.68f).coerceIn(0.22f, 0.98f)
        return gear to rpm
    }

    @Synchronized
    fun getHudTelemetry(): HudTelemetry {
        val (gear, rpm) = computeGearAndRpm()
        return HudTelemetry(
            speedKmh = speedKmh.toInt(),
            distanceMeters = playerZ,
            gear = gear,
            rpmNormalized = rpm,
            nearMissCount = nearMissCount,
            topSpeedReachedKmh = topSpeedReachedKmh.toInt(),
            cameraMode = cameraMode,
            hasCrashed = hasCrashed,
            showNearMissBanner = nearMissBannerTimer > 0f
        )
    }

    @Synchronized
    fun getRenderSnapshot(): RenderSnapshot {
        return RenderSnapshot(
            playerX = playerX,
            playerZ = playerZ,
            speedKmh = speedKmh,
            steerVisualAngleDeg = steerVisualAngleDeg,
            bodyRollDeg = bodyRollDeg,
            wheelSpinRad = wheelSpinRad,
            isBraking = brakeInput > 0.1f,
            hasCrashed = hasCrashed,
            cameraShake = cameraShake,
            cameraMode = cameraMode,
            traffic = trafficList.toList(),
            carSpec = carSpec,
            paintIndex = paintIndex,
            showcaseAngleRad = showcaseAngleRad
        )
    }

    // Exposed for unit testing traffic injection deterministically
    @Synchronized
    internal fun injectTrafficForTest(vehicle: TrafficVehicle) {
        trafficList.add(vehicle)
    }
}
