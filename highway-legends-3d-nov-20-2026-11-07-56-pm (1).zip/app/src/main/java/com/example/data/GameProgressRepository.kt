package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.CarCatalog
import com.example.model.EnvironmentId
import com.example.model.PlayerProgress
import com.example.model.SoundSettings
import com.example.model.SteeringMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.highwayDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "highway_legends_progress"
)

class GameProgressRepository(private val context: Context) {

    private object Keys {
        val SELECTED_CAR = stringPreferencesKey("selected_car_id")
        val SELECTED_PAINT = intPreferencesKey("selected_paint_index")
        val SELECTED_ENV = stringPreferencesKey("selected_environment_id")
        val BEST_DISTANCE = floatPreferencesKey("best_distance_meters")
        val TOTAL_DISTANCE = floatPreferencesKey("total_distance_meters")
        val RACES_COMPLETED = intPreferencesKey("races_completed")

        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val ENGINE_VOLUME = floatPreferencesKey("engine_volume")
        val SFX_VOLUME = floatPreferencesKey("sfx_volume")
        val STEERING_MODE = stringPreferencesKey("steering_mode")

        fun envBestKey(envId: EnvironmentId) = floatPreferencesKey("best_env_${envId.storageKey}")
    }

    private val safePrefsFlow: Flow<Preferences> = context.highwayDataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }

    val progressFlow: Flow<PlayerProgress> = safePrefsFlow.map { prefs ->
        val bestByEnv = EnvironmentId.entries.associateWith { env ->
            prefs[Keys.envBestKey(env)] ?: 0f
        }
        PlayerProgress(
            selectedCarId = prefs[Keys.SELECTED_CAR] ?: CarCatalog.all.first().id,
            selectedPaintIndex = prefs[Keys.SELECTED_PAINT] ?: 0,
            selectedEnvironmentId = EnvironmentId.fromKey(prefs[Keys.SELECTED_ENV]),
            bestDistanceMeters = prefs[Keys.BEST_DISTANCE] ?: 0f,
            totalDistanceMeters = prefs[Keys.TOTAL_DISTANCE] ?: 0f,
            bestDistanceByEnv = bestByEnv,
            racesCompleted = prefs[Keys.RACES_COMPLETED] ?: 0
        )
    }

    val soundSettingsFlow: Flow<SoundSettings> = safePrefsFlow.map { prefs ->
        SoundSettings(
            soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
            engineVolume = prefs[Keys.ENGINE_VOLUME] ?: 0.75f,
            sfxVolume = prefs[Keys.SFX_VOLUME] ?: 0.85f,
            steeringMode = SteeringMode.fromKey(prefs[Keys.STEERING_MODE])
        )
    }

    suspend fun saveSelectedCar(carId: String, paintIndex: Int) {
        context.highwayDataStore.edit { prefs ->
            prefs[Keys.SELECTED_CAR] = carId
            prefs[Keys.SELECTED_PAINT] = paintIndex
        }
    }

    suspend fun saveSelectedEnvironment(envId: EnvironmentId) {
        context.highwayDataStore.edit { prefs ->
            prefs[Keys.SELECTED_ENV] = envId.storageKey
        }
    }

    suspend fun recordRunResult(envId: EnvironmentId, distanceMeters: Float): Boolean {
        var isNewOverallRecord = false
        context.highwayDataStore.edit { prefs ->
            val currentBest = prefs[Keys.BEST_DISTANCE] ?: 0f
            if (distanceMeters > currentBest) {
                prefs[Keys.BEST_DISTANCE] = distanceMeters
                isNewOverallRecord = true
            }
            val envKey = Keys.envBestKey(envId)
            val envBest = prefs[envKey] ?: 0f
            if (distanceMeters > envBest) {
                prefs[envKey] = distanceMeters
            }
            val total = prefs[Keys.TOTAL_DISTANCE] ?: 0f
            prefs[Keys.TOTAL_DISTANCE] = total + distanceMeters
            prefs[Keys.RACES_COMPLETED] = (prefs[Keys.RACES_COMPLETED] ?: 0) + 1
        }
        return isNewOverallRecord
    }

    suspend fun saveSoundSettings(settings: SoundSettings) {
        context.highwayDataStore.edit { prefs ->
            prefs[Keys.SOUND_ENABLED] = settings.soundEnabled
            prefs[Keys.ENGINE_VOLUME] = settings.engineVolume
            prefs[Keys.SFX_VOLUME] = settings.sfxVolume
            prefs[Keys.STEERING_MODE] = settings.steeringMode.storageKey
        }
    }
}
